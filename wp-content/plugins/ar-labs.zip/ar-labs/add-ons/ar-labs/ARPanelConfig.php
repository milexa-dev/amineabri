<?php
if ( ! class_exists( 'ARPanelConfig') ) :
class ARPanelConfig {

    public static function init()
	{
		$class = __CLASS__;
		new $class;
	}

	public function __construct(){
        add_action("wp_dashboard_setup",                       [&$this , 'dashboard_widget']);
        //add_action('welcome_panel',                          [&$this , 'custom_welcome_panel']);
        add_action("admin_init",                               [&$this , "remove_dashboard_meta"]);
        add_action('admin_enqueue_scripts',                    [$this, 'enqueu_scripts']);
    }

    public function dashboard_widget(){
        //wp_add_dashboard_widget("sixthstory", "SixthStory Last Orders", [&$this , 'display_aa_orders']);
    }

    /*public function custom_welcome_panel() {
        $view = new AA_Views();
        $tpl = [
            "view"      => "ar-labs.dashboard.widget.welcome",
            "addon"     => "ar-labs"
        ];
        $view->makeAddonView($tpl);
    }*/

    //callback to display the content in the widget
    /*public function display_aa_orders(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "ar-labs.dashboard.widget.orders",
            "addon"     => "ar-labs"
        ];
        $view->makeAddonView($tpl);
    }*/

    public function remove_dashboard_meta()
    {
        remove_meta_box('dashboard_incoming_links', 'dashboard', "normal");
        remove_meta_box('dashboard_plugins', 'dashboard', 'normal');
        remove_meta_box('dashboard_primary', 'dashboard', 'normal');
        remove_meta_box('dashboard_secondary', 'dashboard', 'normal');
        remove_meta_box('dashboard_quick_press', 'dashboard', 'normal');
        remove_meta_box('dashboard_recent_drafts', 'dashboard', 'normal');
        remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');
        remove_meta_box('dashboard_right_now', 'dashboard', 'normal');
        remove_meta_box('dashboard_activity', 'dashboard', 'normal');
    }
    public function enqueu_scripts(){
        $screen = get_current_screen();
        if($screen->id === "toplevel_page_starter"):
            wp_enqueue_style('bootstrap-main-css', '//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css');
            wp_enqueue_style('admin-main-css', AA_URL . 'assets/css/main.css');

            wp_enqueue_script('jquery-admin-script', '//code.jquery.com/jquery-1.10.2.min.js');
            wp_enqueue_script('boostrap-admin-script', '//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js');
            wp_enqueue_script('admin-script', AA_URL . 'assets/js/app.js',[],false,true);
        endif;
    }
}
endif;