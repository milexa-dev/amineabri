<?php
if ( ! class_exists( 'ARPanelMenu') ) :
class ARPanelMenu {

    /**
     * Loading the menu
     */
    public static function load_menu(){
        $logo = plugins_url( "ar-labs/",  dirname(__FILE__) )."logo.svg";
        add_menu_page(
            'arlabs',
            'Plugin Starter',
            'administrator',
            "starter",
            'ARPanel::setting',
            $logo,
            66
        );
	}

    /**
     * Remove the first menu from the backend sidebar
     */
    public static function removeFirstMenu() {
        global $submenu;

    }
}
endif;
