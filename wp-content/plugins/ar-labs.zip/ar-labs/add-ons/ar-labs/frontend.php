<?php

if ( ! class_exists( 'ARPanelFrontendView') ) :
class ARPanelFrontendView
{

}
endif;