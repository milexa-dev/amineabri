<?php
if ( ! class_exists( 'ARPanelWidget') ) :
class ARPanelWidget {
	public static function init()
	{
		$class = __CLASS__;
		new $class;
	}

	public function __construct(){
        //add_action("wp_dashboard_setup", [&$this , "aa_meta_box"]);

    }
    public function aa_meta_box()
    {
        //add_meta_box("aacommerce_orders", "AA Orders", [&$this , 'display_aa_orders'], "dashboard");
    }



}
endif;