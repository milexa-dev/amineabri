{extends file=$smarty.const.AA_LAYOUTS_PATH}
{block name=content}
<!-- flight section -->
<div class="bhoechie-tab-content active">
    <center>
        <h1 class="glyphicon glyphicon-plane" style="font-size:14em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Flight Reservation</h3>
    </center>
</div>
<!-- train section -->
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-road" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Train Reservation</h3>
    </center>
</div>

<!-- hotel search -->
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-home" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Hotel Directory</h3>
    </center>
</div>
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-cutlery" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Restaurant Diirectory</h3>
    </center>
</div>
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-credit-card" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Credit Card</h3>
    </center>
</div>
{/block}