<?php
if ( ! class_exists( 'ARPanelShortCode') ) :
class ARPanelShortCode {

    public static function init()
    {
        $class = __CLASS__;
        new $class;
    }

    public function __construct(){

    }
}
endif;