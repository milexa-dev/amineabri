<?php
if ( ! class_exists( 'ARPanel') ) :
class ARPanel{

    public static function init()
    {
        $class = __CLASS__;
        new $class;
    }

    public function __construct(){}

    public function setting(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "ar-labs.index",
            "addon"     => "ar-labs"
        ];
        $view->makeAddonView($tpl);
    }
}
endif;