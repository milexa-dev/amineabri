<?php
/* Smarty version 3.1.31, created on 2017-07-24 23:20:39
  from "/home/vagrant/Code/wordpress/wp-content/plugins/ar-labs/templates/layouts/app.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_597680c75c7073_61865632',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9a79fdbb470a108112dd0662c85c3c3eaa91f6d2' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/ar-labs/templates/layouts/app.tpl.php',
      1 => 1500936369,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_597680c75c7073_61865632 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_164992847597680c75c3569_69511327', 'style');
?>

</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-8 col-xs-9 bhoechie-tab-container">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 bhoechie-tab-menu">
                <div class="list-group">
                    <a href="#" class="list-group-item active text-center">
                        <h4 class="glyphicon glyphicon-plane"></h4><br/>Menu 1
                    </a>
                    <a href="#" class="list-group-item text-center">
                        <h4 class="glyphicon glyphicon-road"></h4><br/>Menu 2
                    </a>
                    <a href="#" class="list-group-item text-center">
                        <h4 class="glyphicon glyphicon-home"></h4><br/>Menu 3
                    </a>
                    <a href="#" class="list-group-item text-center">
                        <h4 class="glyphicon glyphicon-cutlery"></h4><br/>Menu 4
                    </a>
                    <a href="#" class="list-group-item text-center">
                        <h4 class="glyphicon glyphicon-credit-card"></h4><br/>Menu 5
                    </a>
                </div>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 bhoechie-tab">
                <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1229352066597680c75c58a4_69897372', 'content');
?>

            </div>
        </div>
    </div>
</div>
</body>
</html><?php }
/* {block 'style'} */
class Block_164992847597680c75c3569_69511327 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_164992847597680c75c3569_69511327',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'content'} */
class Block_1229352066597680c75c58a4_69897372 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1229352066597680c75c58a4_69897372',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
}
