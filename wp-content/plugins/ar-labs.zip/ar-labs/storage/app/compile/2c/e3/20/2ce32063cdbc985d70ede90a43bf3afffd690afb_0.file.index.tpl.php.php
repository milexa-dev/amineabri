<?php
/* Smarty version 3.1.31, created on 2017-07-24 23:20:39
  from "/home/vagrant/Code/wordpress/wp-content/plugins/ar-labs/add-ons/ar-labs/views/ar-labs/index.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_597680c753e343_95951999',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2ce32063cdbc985d70ede90a43bf3afffd690afb' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/ar-labs/add-ons/ar-labs/views/ar-labs/index.tpl.php',
      1 => 1500936369,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_597680c753e343_95951999 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_512861097597680c753c436_10953270', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, @constant('AA_LAYOUTS_PATH'));
}
/* {block 'content'} */
class Block_512861097597680c753c436_10953270 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_512861097597680c753c436_10953270',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<!-- flight section -->
<div class="bhoechie-tab-content active">
    <center>
        <h1 class="glyphicon glyphicon-plane" style="font-size:14em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Flight Reservation</h3>
    </center>
</div>
<!-- train section -->
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-road" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Train Reservation</h3>
    </center>
</div>

<!-- hotel search -->
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-home" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Hotel Directory</h3>
    </center>
</div>
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-cutlery" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Restaurant Diirectory</h3>
    </center>
</div>
<div class="bhoechie-tab-content">
    <center>
        <h1 class="glyphicon glyphicon-credit-card" style="font-size:12em;color:#55518a"></h1>
        <h2 style="margin-top: 0;color:#55518a">Cooming Soon</h2>
        <h3 style="margin-top: 0;color:#55518a">Credit Card</h3>
    </center>
</div>
<?php
}
}
/* {/block 'content'} */
}
