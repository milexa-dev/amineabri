<?php
session_start();
/**
 * Plugin Name:     Plugin Starter for wordpress
 * Plugin URI:      http://www.amineabri.co.uk
 * Github URI:      https://github.com/ar-framework-labs
 * Description:     Plugin starter.
 * Author:          Amine Abri
 * Author URI:      http://www.amineabri.co.uk
 * Version:         1.0.0
 * License:         GPLv3 (ar-labs/license.txt)
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package         ArLabs
 * @author          Amine Abri <hello@amineabri.co.uk>
 * @license         GNU General Public License, version 3
 * @copyright       2016-2017 amineabri.co.uk
 */
if (! defined('ABSPATH')) exit; // Exit if accessed directly.
define('AA_PATH', plugin_dir_path( __FILE__ ));
define('AA_LAYOUTS_PATH', AA_PATH.'templates/layouts/app.tpl.php');
define('AA_URL', plugin_dir_url( __FILE__ ) );
define('AA_BASENAME', 'ar-labs');
define('STYLESHEET_PATH', get_stylesheet_directory());
require_once(ABSPATH . WPINC ."/pluggable.php");
include_once(AA_PATH . 'vendor/autoload.php');

new AA_Core();
