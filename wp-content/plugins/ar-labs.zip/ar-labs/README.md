![Amine Abri](https://raw.github.com/amineabri/ar-labs/master/logo.png)
### Wordpress Plugin Starter
Wordpress Plugin Starter it's a plugin which you can use to develop your own plugin for WordPress.

### Installation
```
cd wp-content/plugins
git clone https://github.com/amineabri/ar-labs.git ar-labs
cd ar-labs
composer update
```

The Wordpress Plugin Starter is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)

[![Owner](https://img.shields.io/badge/copyright-2014--2016-red.svg)](https://github.com/amineabri/wordpress-plugin-framework)
[![Owner](https://img.shields.io/badge/launched-10%2F10%2F2014-ff2f6c.svg)](https://github.com/amineabri/wordpress-plugin-framework)

