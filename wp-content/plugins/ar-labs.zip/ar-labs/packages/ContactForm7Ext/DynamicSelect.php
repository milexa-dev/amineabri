<?php

namespace SixthStoryCF7EXT;

if ( ! class_exists( 'DynamicSelect') ) :
class DynamicSelect
{

    public function __construct() {
        add_action('plugins_loaded', [$this, 'init'], 20);
    }

    public function init() {
        if(function_exists('wpcf7_add_form_tag')){
            /* Shortcode handler */
            wpcf7_add_form_tag('dynamicselect', [$this, 'shortcode_handler'], true);
            wpcf7_add_form_tag('dynamicselect*', [$this, 'shortcode_handler'], true);
        } else {
            wpcf7_add_shortcode('dynamicselect', [$this, 'shortcode_handler'], true);
            wpcf7_add_shortcode('dynamicselect*', [$this, 'shortcode_handler'], true);
        }
        add_filter('wpcf7_validate_dynamicselect', [$this, 'validation_filter'], 10, 2);
        add_filter('wpcf7_validate_dynamicselect*', [$this, 'validation_filter'], 10, 2);
        add_action('admin_init', [$this, 'add_tg_generator'], 25);
    } // end public function init

    public function shortcode_handler($tag) {
        // generates html for form field
        if (!is_array($tag)) {
            return '';
        }
        $name = $tag['name'];
        if (empty($name)) {
            return '';
        }
        $type               = $tag['type'];
        $options            = $tag['options'];
        $values             = $tag['values'];
        $wpcf7_contact_form = \WPCF7_ContactForm::get_current();

        $atts               = '';
        $name_att           = $name;
        $id_att             = '';
        $class_att          = '';
        $multiple_att       = '';
        $tabindex_att       = '';

        $class_att .= ' wpcf7-select';

        if ($type == 'dynamicselect*') {
            $class_att .= ' wpcf7-validates-as-required';
            $atts .= ' aria-required="true"';
        }

        $multiple       = false;
        $returnlabels   = false;
        if (count($options)) {
            foreach ($options as $option) {
                if ($option == 'multiple') {
                    $multiple_att = ' multiple="multiple"';
                    $multiple = true;
                } elseif($option == 'returnlabels') {
                    $returnlabels = true;
                } elseif (preg_match('%^id:([-0-9a-zA-Z_]+)$%', $option, $matches)) {
                    $id_att = $matches[1];
                } elseif (preg_match('%^class:([-0-9a-zA-Z_]+)$%', $option, $matches)) {
                    $class_att .= ' '.$matches[1];
                } elseif (preg_match('%^tabindex:(\d+)$%', $option, $matches)) {
                    $tabindex_att = intval($matches[1]);
                }
            } // end foreach options
        } // end if count $options

        if ($multiple) {
            $name_att .= '[]';
        }

        $atts .= ' name="'.$name_att.'"';
        if ($id_att) {
            $atts .= ' id="'.trim($id_att).'"';
        }
        if ($class_att) {
            $atts .= ' class="'.trim($class_att).'"';
        }
        if ($tabindex_att) {
            $atts .= ' tabindex-"'.$tabindex_att.'"';
        }
        $atts .= ' '.$multiple_att;

        $value = '';
        if (is_a($wpcf7_contact_form, 'WPCF7_ContactForm') && $wpcf7_contact_form->is_posted()) {
            if (isset($_POST['_wpcf7_mail_sent']) && $_POST['_wpcf7_mail_sent']['ok']) {
                $value = '';
            } else {
                $value = stripslashes_deep($_POST[$name]);
            }
        } else {
            if (isset($_GET[$name])) {
                $value = stripslashes_deep($_GET[$name]);
            }
        }
        $filter         = '';
        $filter_args    = [];
        $filter_string  = '';
        if (isset($values[0])) {
            $filter_string = $values[0];
        }
        if ($filter_string != '') {
            $filter_parts = explode(' ', $filter_string);
            $filter = trim($filter_parts[0]);
            $count = count($filter_parts);
            for($i=1; $i<$count; $i++) {
                if (trim($filter_parts[$i]) != '') {
                    $arg_parts = explode('=', $filter_parts[$i]);
                    if (count($arg_parts) == 2) {
                        $filter_args[trim($arg_parts[0])] = trim($arg_parts[1], ' \'');
                    } else {
                        $filter_args[] = trim($arg_parts[0], ' \'');
                    }
                } // end if filter part
            } // end for
        } // end if filter string
        if ($filter == '') {
            return $filter;
        }
        $field_options = apply_filters($filter, [], $filter_args);

        if (!is_array($field_options) || !count($field_options)) {
            // filter did not return an array of values
            return '';
        }

        $validation_error = '';
        if (is_a($wpcf7_contact_form, 'WPCF7_ContactForm')) {
            $validation_error = $wpcf7_contact_form->validation_error($name);
        }
        $invalid = 'false';
        if ($validation_error) {
            $invalid = true;
            $atts .= ' aria-invalid="'.$invalid.'"';
        }

        $default = '';
        if (isset($field_options['default'])) {
            $default = $field_options['default'];
            unset($field_options['default']);
        }
        if (!is_array($default)) {
            $default = [$default];
        }
        if (!$multiple && count($default) > 1) {
            $default = [array_pop($default)];
        }
        $use_default = true;
        if (isset($_POST[$name]) || isset($_GET[$name])) {
            $use_default = false;
        }

        ob_start();
            include("views/select.php");
        $html = ob_get_clean();
        return $html;
    }

    public function validation_filter($result, $tag) {
        // valiedates field on submit
        $wpcf7_contact_form = \WPCF7_ContactForm::get_current();
        $type = $tag['type'];
        $name = $tag['name'];
        if ($type != 'dynamicselect*') {
            return $result;
        }
        $value_found = false;
        if (isset($_POST[$name])) {
            $value = $_POST[$name];
            if (!is_array($value) && trim($value) != '') {
                $value_found = true;
            }
            if (is_array($value) && count($value)) {
                foreach ($value as $item) {
                    if (trim($item) != '') {
                        $value_found = true;
                        break;
                    }
                } // end foreach value
            } // end if array && count
        } // end if set
        if (!$value_found) {
            $result->invalidate($tag, wpcf7_get_message('invalid_required'));
        }
        return $result;
    }

    public function add_tg_generator() {
        // called on init to add the tag generator or cf7
        // wpcf7_add_tag_generator($name, $title, $elm_id, $callback, $options = array())
        if (!function_exists('wpcf7_add_tag_generator')) {
            return;
        }
        $name     = 'dynamicselect';
        $title    = __('Dynamic Select EXT FOR CF7', 'wpcf7');
        $elm_id   = 'wpcf7-tg-pane-dynamicselect';
        $callback = [$this, 'tg_pane'];
        wpcf7_add_tag_generator($name, $title, $elm_id, $callback);
    }

    public function tg_pane($form, $args = '') {
        // output the code for CF7 tag generator
        $type   =   'dynamicselect';
        if (class_exists('WPCF7_TagGenerator')) {
            // tag generator for CF7 >= v4.2
            $args      = wp_parse_args( $args, []);
            $desc      = __('Generate a form-tag for a Dynamic Select field. For more details, see %s.');
            include("views/form.php");
        } else {
            include("views/form-2.php");
        }

    }
}
endif;