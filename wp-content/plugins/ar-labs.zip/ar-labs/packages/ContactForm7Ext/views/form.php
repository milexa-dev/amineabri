<div class="control-box">
    <fieldset>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="<?php
                    echo esc_attr($args['content'].'-required'); ?>"><?php
                        echo esc_html(__('Required field', 'contact-form-7')); ?></label>
                </th>
                <td>
                    <input type="checkbox" name="required" id="<?php
                    echo esc_attr($args['content'].'-required' ); ?>" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="<?php
                    echo esc_attr($args['content'].'-name'); ?>"><?php
                        echo esc_html(__('Name', 'contact-form-7')); ?></label>
                </th>
                <td>
                    <input type="text" name="name" class="tg-name oneline" id="<?php
                    echo esc_attr($args['content'].'-name' ); ?>" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="<?php
                    echo esc_attr($args['content'].'-id'); ?>"><?php
                        echo esc_html(__('Id attribute', 'contact-form-7')); ?></label>
                </th>
                <td>
                    <input type="text" name="id" class="idvalue oneline option" id="<?php
                    echo esc_attr($args['content'].'-id'); ?>" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="<?php
                    echo esc_attr($args['content'].'-class'); ?>"><?php
                        echo esc_html(__('Class attribute', 'contact-form-7'));?></label>
                </th>
                <td>
                    <input type="text" name="class" class="classvalue oneline option" id="<?php
                    echo esc_attr($args['content'].'-class'); ?>" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="<?php
                    echo esc_attr($args['content'].'-values'); ?>"><?php
                        echo esc_html(__('Filter')); ?></label>
                </th>
                <td>
                    <input type="text" name="values" class="tg-name oneline" id="<?php
                    echo esc_attr($args['content'].'-values' ); ?>" /><br />
                    <?php
                    echo esc_html(__('You can enter any filter. Use single quotes only. 
														                  See docs &amp; examples.'));
                    ?>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="<?php
                    echo esc_attr($args['content'].'-multiple'); ?>"><?php
                        echo esc_html(__('Allow multiple selections', 'contact-form-7')); ?></label>
                </th>
                <td>
                    <input type="checkbox" name="multiple" class="multiplevalue option" id="<?php
                    echo esc_attr($args['content'].'-multiple' ); ?>" />
                </td>
            </tr>
            <!--
									<tr>
										<th scope="row">
											<label for="<?php
            echo esc_attr($args['content'].'-returnlabels'); ?>"><?php
            echo esc_html(__('Return Label(s)', 'contact-form-7')); ?></label>
										</th>
										<td>
											<input type="checkbox" name="returnlabels" class="returnlabelsvalue option" id="<?php
            echo esc_attr($args['content'].'-returnlabel' ); ?>" />
											Check this box to return labels instead of values.
										</td>
									</tr>
									-->
            </tbody>
        </table>
    </fieldset>
</div>
<div class="insert-box">
    <input type="text" name="dynamicselect" class="tag code" readonly="readonly" onfocus="this.select()" />
    <div class="submitbox">
        <input type="button" class="button button-primary insert-tag" value="<?php
        echo esc_attr(__('Insert Tag', 'contact-form-7')); ?>" />
    </div>
</div>