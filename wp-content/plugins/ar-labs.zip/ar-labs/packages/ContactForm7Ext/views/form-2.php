<div id="wpcf7-tg-pane-<?php echo $type; ?>" class="control-box">
    <form action="">
        <table>
            <tr>
                <td>
                    <input type="checkbox" name="required" />
                    <?php echo esc_html(__('Required field?', 'contact-form-7')); ?>
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo esc_html(__( 'Name', 'contact-form-7')); ?><br />
                    <input type="text" name="name" class="tg-name oneline" />
                </td>
                <td></td>
            </tr>
        </table>
        <table>
            <tr>
                <td>
                    <code>id</code> (<?php echo esc_html(__('optional', 'contact-form-7')); ?>)<br />
                    <input type="text" name="id" class="idvalue oneline option" />
                </td>
                <td>
                    <code>class</code> (<?php echo esc_html(__('optional', 'contact-form-7')); ?>)<br />
                    <input type="text" name="class" class="classvalue oneline option" />
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo esc_html(__('Filter')); ?><br />
                    <input type="text" name="values" class="oneline" /><br />
                    <?php echo esc_html(__('You can enter any filter. Use single quotes only. See docs &amp; examples.')); ?>
                </td>
                <td>
                    <br />
                    <input class="option" type="checkbox" name="multiple">
                    Allow multiple selections?
                </td>
            </tr>
        </table>
        <div class="tg-tag">
            <?php echo esc_html(__('Copy this code and paste it into the form left.', 'contact-form-7')); ?><br />
            <input type="text" name="<?php
            echo $type; ?>" class="tag" readonly="readonly" onfocus="this.select()" style="width:100%;" />
        </div>
        <div class="tg-mail-tag">
            <?php echo esc_html(__('And, put this code into the Mail fields below.', 'contact-form-7')); ?><br />
            <input type="text" class="mail-tag" readonly="readonly" onfocus="this.select()" style="width:100%;" />
        </div>
    </form>
</div>