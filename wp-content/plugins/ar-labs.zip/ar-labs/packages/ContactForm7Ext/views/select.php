<span class="wpcf7-form-control-wrap <?php echo $name; ?>">
					<select <?php echo trim($atts); ?>>
<?php
foreach ($field_options as $option_label => $option_value) {
    $option_value =  esc_attr($option_value);
    $option_label = esc_attr($option_label);
    ?>
    <option value="<?php echo $option_value; ?>"<?php
    if (!$use_default) {
        if (!is_array($value) && $value == $option_value) {
            echo ' selected="selected"';
        } elseif (is_array($value) && in_array($option_value, $value)) {
            echo ' selected="selected"';
        }
    } else {
        if (in_array($option_value, $default)) {
            echo ' selected="selected"';
        }
    }
    ?>><?php echo $option_label; ?></option>
    <?php
} // end foreach field value
?>
</select>
<?php echo $validation_error; ?>
</span>