<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;

class StripeSubscriptions {

    private static $api_key;
    private static $api_version;
    private static $_stripe;


    /**
     * StripeSubscriptions constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function CreateSubscription($customer_id){
        try {
            $subscription = self::$_stripe->subscriptions()->create($customer_id);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @param $subscriptionId
     * @return mixed
     */
    public function GetSubscriptionInfo($customer_id, $subscriptionId){
        try {
            $subscription = self::$_stripe->subscriptions()->find($customer_id,$subscriptionId);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @param $subscriptionId
     * @param $parameters
     * @return mixed
     */
    public function UpdateSubscriptionInfo($customer_id, $subscriptionId, $parameters){
        try {
            $subscription = self::$_stripe->subscriptions()->update($customer_id,$subscriptionId,$parameters);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @param $subscriptionId
     * @param bool $atPeriodEnd
     * @return mixed
     */
    public function CancelSubscription($customer_id, $subscriptionId, $atPeriodEnd = true){
        try {
            $subscription = self::$_stripe->subscriptions()->cancel($customer_id,$subscriptionId,$atPeriodEnd);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @param $subscriptionId
     * @return mixed
     */
    public function ReactivateASubscription($customer_id, $subscriptionId){
        try {
            $subscription = self::$_stripe->subscriptions()->reactivate($customer_id,$subscriptionId);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @param $subscriptionId
     * @return mixed
     */
    public function DeleteSubscription($customer_id, $subscriptionId){
        try {
            $subscription = self::$_stripe->subscriptions()->deleteDiscount($customer_id,$subscriptionId);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function GetAllSubscriptions($customer_id){
        try {
            $subscription = self::$_stripe->subscriptions()->all($customer_id);
            return $subscription;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }
}