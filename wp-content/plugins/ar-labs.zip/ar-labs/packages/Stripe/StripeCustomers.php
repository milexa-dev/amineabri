<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;

class StripeCustomers {
    private static $api_key;
    private static $api_version;
    private static $_stripe;


    /**
     * StripeCustomers constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @param $data
     * @return mixed
     */
    public function CreateCustomer($data){
        try {
            $customer = self::$_stripe->customers()->create($data);
            return $customer['id'];
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function GetCustomerInfo($customer_id){
        try {
            $customer = self::$_stripe->customers()->find($customer_id);
            return $customer;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @param $parameters
     * @return mixed
     */
    public function UpdateCustomerInfo($customer_id, $parameters){
        try {
            $customer = self::$_stripe->customers()->update($customer_id,$parameters);
            return $customer;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function DeleteCustomer($customer_id){
        try {
            $customer = self::$_stripe->customers()->delete($customer_id);
            return $customer;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function DeleteCustomerDiscount($customer_id){
        try {
            $customer = self::$_stripe->customers()->deleteDiscount($customer_id);
            return $customer;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @return mixed
     */
    public function GetAllCustomer(){
        try {
            $customer = self::$_stripe->customers()->all();
            return $customer;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }
}