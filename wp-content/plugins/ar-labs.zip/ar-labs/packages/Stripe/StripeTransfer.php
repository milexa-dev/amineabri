<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;

class StripeTransfer
{
    private static $api_key;
    private static $api_version;
    private static $_stripe;

    /**
     * StripeBalance constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @return string
     */
    public function CreateTransfer($args){
        try {
            $transfers = self::$_stripe->transfers()->create($args);
            return $transfers;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }


    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }
}