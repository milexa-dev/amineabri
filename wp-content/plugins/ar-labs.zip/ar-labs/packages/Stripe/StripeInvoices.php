<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;

class StripeInvoices {
    private static $api_key;
    private static $api_version;
    private static $_stripe;


    /**
     * StripeInvoices constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function CreateInvoice($customer_id){
        try {
            $invoice = self::$_stripe->invoices()->create($customer_id);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $invoice_id
     * @return mixed
     */
    public function GetInvoiceInfo($invoice_id){
        try {
            $invoice = self::$_stripe->invoices()->find($invoice_id);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }


    /**
     * @param $invoice_id
     * @return mixed
     */
    public function GetInvoiceLineItems($invoice_id){
        try {
            $invoice = self::$_stripe->invoices()->invoiceLineItems($invoice_id);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customer_id
     * @return mixed
     */
    public function GetAnUpcomingInvoice($customer_id){
        try {
            $invoice = self::$_stripe->invoices()->upcomingInvoice($customer_id);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }


    /**
     * @param $invoice_id
     * @param $parameters
     * @return mixed
     */
    public function UpdateInvoice($invoice_id, $parameters){
        try {
            $invoice = self::$_stripe->invoices()->update($invoice_id,$parameters);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $invoice_id
     * @return mixed
     */
    public function PayAnInvoice($invoice_id){
        try {
            $invoice = self::$_stripe->invoices()->pay($invoice_id);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @return mixed
     */
    public function GetAllInvoices(){
        try {
            $invoice = self::$_stripe->invoices()->all();
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }

}