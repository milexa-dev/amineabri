<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;

class StripeAccount
{
    private static $api_key;
    private static $api_version;
    private static $_stripe;

    /**
     * StripeBalance constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @return string
     */
    public function AccountDetails(){
        try {
            $account = self::$_stripe->account()->details();
            return $account;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }

    public function CreateAccount($args){
        try {
            $account = self::$_stripe->account()->create($args);
            return $account;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }

    public function ConnectedAccounts($args = ["limit" => 3]){
        try {
            $account = self::$_stripe->account()->all($args);
            return $account;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }

    public function RetrieveAccount($args){
        try {
            $account = self::$_stripe->account()->find($args);
            return $account;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }

    public function DeleteAccount($account_id){
        try {
            $account = self::$_stripe->account()->delete($account_id);
            return $account;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }

    public function RejectAccount($account_id,$reason){
        try {
            $account = self::$_stripe->account()->reject($account_id,$reason);
            return $account;
        } catch (\Exception   $e) {
            return $e->getMessage();
        }
    }


    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }
}