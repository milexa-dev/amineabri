<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;
class StripeCoupons {

    private static $api_key;
    private static $api_version;
    private static $_stripe;


    /**
     * StripeCoupons constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @param $parameters
     * @return mixed
     */
    public function CreateCoupon($parameters){
        try {
            $coupon = self::$_stripe->coupons()->create($parameters);
            return $coupon;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $couponId
     * @return mixed
     */
    public function GetCoupon($couponId){
        try {
            $coupon = self::$_stripe->coupons()->find($couponId);
            return $coupon;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $couponId
     * @param $parameters
     * @return mixed
     */
    public function UpdateCoupon($couponId, $parameters){
        try {
            $coupon = self::$_stripe->coupons()->update($couponId,$parameters);
            return $coupon;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $couponId
     * @return mixed
     */
    public function DeleteCoupon($couponId){
        try {
            $coupon = self::$_stripe->coupons()->delete($couponId);
            return $coupon;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @return mixed
     */
    public function GetAllCoupons(){
        try {
            $coupon = self::$_stripe->coupons()->all();
            return $coupon;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }
}