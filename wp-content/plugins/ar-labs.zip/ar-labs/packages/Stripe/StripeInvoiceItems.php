<?php
namespace SixthStory;
use Cartalyst\Stripe\Stripe;


class StripeInvoiceItems {
    private static $api_key;
    private static $api_version;
    private static $_stripe;


    /**
     * StripeInvoiceItems constructor.
     */
    function __construct($key = null) {
        $res = self::init();
        if(is_null($key)):
            self::$api_key     = (!is_null($res)) ? $res['key']:'';
        else:
            self::$api_key     = $key;
        endif;
        self::$api_version = (!is_null($res)) ? $res['version']:'';
        self::$_stripe     = new Stripe(self::$api_key, self::$api_version);
    }

    /**
     * @param $customer_id
     * @param $parameters
     * @return mixed
     */
    public function InvoiceItems($customer_id, $parameters){
        try {
            $invoice = self::$_stripe->invoiceItems()->create($customer_id,$parameters);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $invoiceItemId
     * @return mixed
     */
    public function GetInvoiceItem($invoiceItemId){
        try {
            $invoice = self::$_stripe->invoiceItems()->find($invoiceItemId);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $invoiceItemId
     * @param $parameters
     * @return mixed
     */
    public function UpdateAnInvoiceItem($invoiceItemId, $parameters){
        try {
            $invoice = self::$_stripe->invoiceItems()->update($invoiceItemId,$parameters);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $invoiceItemId
     * @return mixed
     */
    public function DeleteAnInvoiceItem($invoiceItemId){
        try {
            $invoice = self::$_stripe->invoiceItems()->delete($invoiceItemId);
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @return mixed
     */
    public function GetAllInvoiceItems(){
        try {
            $invoice = self::$_stripe->invoiceItems()->all();
            return $invoice;
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private static function init(){
        $setting = (get_option( 'STRIPE_SETTING' ) == true) ? get_option( 'STRIPE_SETTING' ) : null;
        if(!is_null($setting)):
            if($setting['stripe']['active'] == 'on'):
                if($setting['stripe']['testmode'] == 'on'):
                    return [
                        'key'      => $setting['stripe']['test_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                else:
                    return [
                        'key'      => $setting['stripe']['live_sk'],
                        'version'  => $setting['stripe']['version']
                    ];
                endif;
            else:
                return null;
            endif;
        else:
            return [
                'key'      => STRIPE_KEY,
                'version'  => STRIPE_VERSION
            ];
        endif;
    }
}