<?php
/**
 * Class Admin.
 * User: Amine Abri
 * Date: 25/06/2016
 * Time: 14:19
 */
if (! class_exists('Admin')) :
class Admin{
	public static function index(){
		$view = new AA_Views();
		$view->make('admin.index');
	}

	public static function setting(){
		$view = new AA_Views();
		$view->make('admin.setting');
	}

	public static function systemstatus(){
		$view = new AA_Views();
		$view->make('admin.systemstatus');
	}

	public static function addons(){
        $view = new AA_Views();
        $view->make('admin.addons');
	}

	public static function reports(){
        $view = new AA_Views();
        $view->make('admin.reports');
	}
}
endif;