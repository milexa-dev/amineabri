<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * AACommerce menu
 *
 * @class 		AA_Menu
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_Menu') ) :
class AA_Menu {
	public function __construct(){
		add_action('admin_menu', [&$this , 'RegisterAdminMenu']);
        add_action('admin_head', [&$this, 'aa_menu_order_count']);
        add_action('admin_bar_menu', [&$this, 'aa_admin_bar_menu'], 1000);
        add_action( 'admin_enqueue_scripts', [&$this, 'custom_wp_toolbar_css_admin']);
        add_action( 'wp_enqueue_scripts', [&$this, 'custom_wp_toolbar_css_admin']);
	}

	public function RegisterAdminMenu() {
		/* Menu Position
		 * 5 - below Posts
		 * 10 - below Media
		 * 15 - below Links
		 * 20 - below Pages
		 * 25 - below comments
		 * 60 - below first separator
		 * 65 - below Plugins
		 * 70 - below Users
		 * 75 - below Tools
		 * 80 - below Settings
		 * 100 - below second separator
		 */
		add_menu_page(
			'Dashboard',
			'L.M.S',
			'administrator',
			"aa",
			'Admin::index',
            AA_URL.'assets/images/sixthstory.svg',
			65
		);
		$this->RegisterAdminSubMenu();
	}

	protected static function loadMenuAddons(){
		$dirs = glob(AA_PATH .'add-ons/*', GLOB_MARK);
		$menu = null;
		foreach ($dirs as $dir) {
			if (is_dir($dir)) {
				$path  =  AA_PATH.'add-ons/'.basename($dir)."/";
				$menu  =  self::read($path."setting.json");
				$class      = $menu["menuClass"];
				$mn         = $menu["menu"];
				require($path.$mn);
				if(class_exists("$class")){
					$class::load_menu();
                    add_action('admin_head', "$class::removeFirstMenu");
				}else{
					die("Cannot Load Addon Menu");
					exit;
				}
			}
		}
	}

	protected static function need($path)
	{
		if(file_exists($path))
			return require_once $path;
	}

	protected static function read($string)
	{
		$autoload = self::convert(file_get_contents($string));
		$autoload = $autoload["system"]["autoload"][0];
		return $autoload;
	}

	protected static function convert($string)
	{
		$data = json_decode($string,true);
		return $data;
	}

	public function RegisterAdminSubMenu(){
		self::loadMenuAddons();
        add_submenu_page(
            'aa',
            'Orders',
            'Orders',
            'administrator',
            'aa.orders',
            'Admin::index'
        );

        add_submenu_page(
            'aa',
            'Reports',
            'Reports',
            'administrator',
            'aa.reports',
            'Admin::reports'
        );

        add_submenu_page(
            'aa',
            'System Status',
            'System Status',
            'administrator',
            'aa.system_status',
            'Admin::systemstatus'
        );

		add_submenu_page(
			'aa',
			'Settings',
			'Settings',
			'administrator',
			'aa.setting',
			'Admin::setting'
		);

		add_submenu_page(
			'aa',
			'Add-ons',
			'Add-ons',
			'administrator',
			'aa.addons',
			'Admin::addons'
		);
	}


    public function aa_admin_bar_menu() {
        global $wp_admin_bar;

        if (!is_super_admin() || !is_admin_bar_showing())
            return;
        $wp_admin_bar->add_menu([
            'id'    => 'aa-commerce',
            'title' => "<span class='ab-icon'></span> <span class='ab-label'>L.M.S</span>",
            'href'  => false
        ]);
        $wp_admin_bar->add_menu([
            'parent'    => 'aa-commerce',
            'title'     => 'Customer Orders <b>(16)</b>',
            'href'      => '/wp-admin/admin.php?page=aa.orders',
            'meta'      => [
                'target' => '_self',
                'class' => 'orders-link',
                'title' => 'Orders'
            ]
        ]);
        $wp_admin_bar->add_menu([
            'parent'    => 'aa-commerce',
            'title'     => 'Products <b>(16)</b>',
            'href'      => '/wp-admin/admin.php?page=product.list',
            'meta'      => [
                'target' => '_self',
                'class' => 'products-link',
                'title' => 'Products'
            ]
        ]);
    }

    public function custom_wp_toolbar_css_admin() {
        $path = str_replace('src/','',AA_URL);
        wp_register_style('add_custom_wp_toolbar_css', $path . 'assets/css/custom-wp-toolbar-link.css','','', 'screen' );
        wp_enqueue_style('add_custom_wp_toolbar_css' );
    }

    /**
     * Adds the order processing count to the menu.
     */
    public function aa_menu_order_count() {
        global $submenu;

        if ( isset( $submenu['aa'] ) ) {
            unset( $submenu['aa'][0] );
            // Add count if user has access
            foreach ( $submenu['aa'] as $key => $menu_item ) {
                if ( 0 === strpos( $menu_item[0], 'Orders') ) {
                    $submenu['aa'][ $key ][0] .= ' <span class="awaiting-mod update-plugins count-16"><span class="processing-count">16</span></span>';
                    break;
                }
            }
        }
    }

}
endif;

