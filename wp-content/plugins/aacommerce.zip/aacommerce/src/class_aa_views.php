<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * AACommerce views
 *
 * @class 		AA_Views
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_Views') ) :
class AA_Views {
	public static $tmp;

	public function __construct() {
		self::$tmp = new AA_Template();
	}

	public static function make($view,$data=null){
		$name = str_replace('.', '/', $view);
		$link = plugin_dir_path( __FILE__ ) . "../templates/" . $name . '.tpl.php';
		if (file_exists($link)) {
			self::$tmp->show( $link, $data );
		}else{
			echo "View Not Found";
		}
	}

	public static function makeAddonView($view,$data=null){
		if(is_array($view)){
			$name       = str_replace('.', '/', $view["view"]);
			$AddonName  = $view["addon"];
			$link = plugin_dir_path( __FILE__ ) . "../add-ons/".$AddonName."/views/" . $name . ".tpl.php";
			if (file_exists($link)) {
				self::$tmp->show( $link, $data );
			}else{
				echo "View Not Found";
			}
		}
	}

	public static function get($view,$data=null){
		ob_start();
		$name = str_replace('.', '/', $view);
		$link = plugin_dir_path( __FILE__ ) . "../templates/" . $name . '.tpl.php';
		if (file_exists($link)) {
            self::$tmp->show($link, $data);
		}else{
			echo "View Not Found";
		}
		$returned_value = ob_get_contents();    // get contents from the buffer
		ob_end_clean();
		return $returned_value;
	}
}
endif;