<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * AACommerce template
 *
 * @class 		AA_Template
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_Template') ) :
class AA_Template {
	public static $smarty;
	public function __construct()
	{
		self::$smarty = new Smarty();
		self::setParams();
		self::setCache();
	}

	public static function registerClassInSmarty($alias, $namespace){
		self::$smarty->registerClass($alias, $namespace);
	}

	public static function show($view,$data=null)
	{
		self::assignData($data);
		return self::displayViews($view);
	}

	public static function setCache()
	{
		self::$smarty->setCacheDir( plugin_dir_path( __FILE__ ) . "/../storage/app/cache");
		self::$smarty->setCompileDir( plugin_dir_path( __FILE__ ) . "/../storage/app/compile");
	}

	public  static function setParams()
	{
		self::$smarty->force_compile    = false;
		self::$smarty->debugging        = false;
		self::$smarty->caching          = false;
		self::$smarty->cache_lifetime   = 120;
		self::$smarty->use_sub_dirs		= true;
		self::$smarty->left_delimiter 	= '{';
		self::$smarty->right_delimiter 	= '}';
		self::$smarty->setPluginsDir(array(
			plugin_dir_path( __FILE__ ) . "/../storage/_plugins"
		));

	}

	public static function displayViews($view)
	{
		return self::$smarty->display($view);
	}

	public static function assignData($data)
	{
		if(!is_null($data))
			foreach ($data as $key => $value)
				self::$smarty->assign($key, $value);
	}
}
endif;