<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * AACommerce template
 *
 * @class 		AA_ShortCode
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_ShortCode') ) :
class AA_ShortCode
{
    public function __construct() {
        add_action('init', [$this, 'add_shortcodes']);
        add_filter('the_content', [$this, 'filter_eliminate_autop']);
        add_filter('widget_text', [$this, 'filter_eliminate_autop']);
    }

    public function filter_eliminate_autop( $content ) {
        $block = join( "|", self::getTags());

        // replace opening tag
        $content = preg_replace( "/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/", "[$2$3]", $content );

        // replace closing tag
        $content = preg_replace( "/(<p>)?\[\/($block)](<\/p>|<br \/>)/", "[/$2]", $content );
        return $content;
    }

    public function add_shortcodes() {
        $shortCodes = self::getAddonsShortcode();
        foreach ($shortCodes as $class => $shortcode ) {
            foreach($shortcode as $methods) {
                $function_name  = $methods;
                $tag            = str_replace("shortcode_", '', $methods);
                $classname      = $class;
                add_shortcode($tag, "$classname::$function_name");
            }
        }
    }

    protected function getAddonsShortcode(){
        $dirs           = glob(plugin_dir_path( __FILE__ ) .'../add-ons/*', GLOB_MARK);
        $menu           = null;
        $class_methods  = [];
        $class_names    = [];
        foreach ($dirs as $dir) {
            if (is_dir($dir)) {
                $path       =  plugin_dir_path( __FILE__ ).'../add-ons/'.basename($dir)."/";
                $menu       =  self::read($path."setting.json");
                $class      = $menu["shortCodeClass"];
                $sc_file    = $menu["shortcode"];
                require($path.$sc_file);
                new $class();
                if(class_exists("$class")){
                    foreach(get_class_methods(new $class()) as $method){
                        $class_methods[$class][] = $method;
                    }
                }else{
                    die("Cannot Load Addon ShortCode");
                    exit;
                }
            }
        }
        return $class_methods;
    }

    protected static function getTags(){
        $data       = [];
        $shortCodes = self::getAddonsShortcode();
        foreach ($shortCodes as $shortcode ) {
            foreach($shortcode as $methods){
                $data[]   = str_replace("shortcode_", '',$methods);
            }
        }
        return $data;
    }

    protected static function read($string)
    {
        $autoload = self::convert(file_get_contents($string));
        $autoload = $autoload["system"]["autoload"][0];
        return $autoload;
    }

    protected static function convert($string)
    {
        $data = json_decode($string,true);
        return $data;
    }
}
endif;