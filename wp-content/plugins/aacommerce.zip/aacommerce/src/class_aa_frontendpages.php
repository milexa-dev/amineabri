<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * AACommerce core
 *
 * @class 		AA_FrontEndPages
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_FrontEndPages') ) :
class AA_FrontEndPages
{

    public function __construct() {
//        /add_action('init', [&$this , 'add_pages']);
        //add_action('wp_head', [&$this , 'CopyFile']);
    }

    public function add_pages() {
        $pages = self::getAddonsFrontEndPages();
        foreach ($pages as $class => $page ) {
            foreach($page as $methods) {
                $function_name  = $methods;
                $classname      = $class;
                add_action( 'wp', "$classname::$function_name");
            }
        }
    }

    public function createAACommerceThemeDirectory(){
        $dir = get_stylesheet_directory() . '/lms/';
        if (!file_exists($dir)) {
            mkdir(get_stylesheet_directory() . '/lms/', 0777);
        }
        return get_stylesheet_directory() . '/lms/';
    }

    public function CopyFile() {
        $plugin_dir     = null;
        $theme_dir      = $this->createAACommerceThemeDirectory();
        $dirs           = glob(AA_PATH .'add-ons/*', GLOB_MARK);

        foreach ($dirs as $dir) {
            if (is_dir($dir)) {
                $plugin_dir     = AA_PATH.'add-ons/'.basename($dir)."/views/frontend/";
                foreach (glob($plugin_dir.'*.php') as $filename) {
                    if(!file_exists($theme_dir.basename($filename))){
                        if(!copy($plugin_dir.basename($filename), $theme_dir.basename($filename))){
                            return false;
                        }
                    }
                }
            }
        }
    }


    protected function getAddonsFrontEndPages(){
        $dirs           = glob(AA_PATH.'add-ons/*', GLOB_MARK);
        $menu           = null;
        $class_methods  = [];
        $class_names    = [];
        foreach ($dirs as $dir) {
            if (is_dir($dir)) {
                $path       =  AA_PATH.'add-ons/'.basename($dir)."/";
                $menu       =  self::read($path."setting.json");
                $class      = $menu["frontEndViewClass"];
                $sc_file    = $menu["frontEnd"];
                require($path.$sc_file);
                if(class_exists("$class")){
                    foreach(get_class_methods(new $class()) as $method){
                        $class_methods[$class][] = $method;
                    }
                }else{
                    die("Cannot Load Addon ShortCode");
                    exit;
                }
            }
        }
        return $class_methods;
    }

    protected static function read($string)
    {
        $autoload = self::convert(file_get_contents($string));
        $autoload = $autoload["system"]["autoload"][0];
        return $autoload;
    }

    protected static function convert($string)
    {
        $data = json_decode($string,true);
        return $data;
    }
}
endif;