<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * AACommerce core
 *
 * @class 		AA_DashboardWidgets
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_DashboardWidgets') ) :
class AA_DashboardWidgets
{
    public function __construct() {
        add_action("wp_dashboard_setup", [&$this , 'aa_dashboard']);
        //add_action("wp_dashboard_setup", [&$this , "aa_meta_box"]);
        add_action("admin_init", [&$this , "aa_remove_dashboard_meta"]);
        add_action( 'welcome_panel', [&$this , 'aa_welcome_panel']);
    }

    public function aa_dashboard()
    {
        //this function is used to create a widget.
        //first parameter -> unique id/slug for that widget
        //second parameter -> title of the widget
        //third parameter -> callback used to display content of the widget
        wp_add_dashboard_widget("aacommerce", "SixthStory Last Orders", [&$this , 'display_aa_orders']);
    }

    //callback to display the content in the widget
    public function display_aa_orders(){
        $view = new AA_Views();
        $result = $view->get('admin.dashboard.widget.orders');
        echo $result;
    }

    public function aa_meta_box()
    {
        //add_meta_box("aacommerce_orders", "AA Orders", [&$this , 'display_aa_orders'], "dashboard");
    }

    public function aa_welcome_panel() {
        $view = new AA_Views();
        $result = $view->get('admin.dashboard.widget.welcome');
        echo $result;
    }


    public function aa_remove_dashboard_meta()
    {
        //first parameter -> slig/id of the widget
        //second parameter -> where the meta box is displayed, it can be page, post, dashboard etc.
        //third parameter -> position of the meta box. If you have used wp_add_dashboard_widget to create the widget or deleting default widget then provide the value "normal".
        remove_meta_box('dashboard_incoming_links', 'dashboard', "normal");
        remove_meta_box('dashboard_plugins', 'dashboard', 'normal');
        remove_meta_box('dashboard_primary', 'dashboard', 'normal');
        remove_meta_box('dashboard_secondary', 'dashboard', 'normal');
        remove_meta_box('dashboard_quick_press', 'dashboard', 'normal');
        remove_meta_box('dashboard_recent_drafts', 'dashboard', 'normal');
        remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');
        remove_meta_box('dashboard_right_now', 'dashboard', 'normal');
        remove_meta_box('dashboard_activity', 'dashboard', 'normal');
    }

}
endif;