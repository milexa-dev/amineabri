<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
/**
 * AACommerce core
 *
 * @class 		AA_Widgets
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_Widgets') ) :
class AA_Widgets extends WP_Widget {

    public function __construct() {
        parent::__construct('aa_widget', 'AA Commerce',['description' => "Simple Widget for E-commerce",]);
    }



}
endif;