<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * AACommerce core
 *
 * @class 		AA_Core
 * @version		2.1.0
 * @package		AaCommerce/Classes
 * @category	Class
 * @author 		AmineAbri
 */
if ( ! class_exists( 'AA_Core') ) :
class AA_Core {


	public function __construct() {
        self::init();
	}

    public function init(){
        new AA_Menu();
        new AA_ShortCode();
        new AA_Widgets();
        new AA_DashboardWidgets();
        new AA_FrontEndPages();

        self::LoadAddonClass();
        self::setup();
        self::loadmodels();
        self::loadcontrollers();

        //self::StyleFile();
        //self::ScriptFile();
        add_action('admin_menu', [&$this , 'remove_menus']);
        add_action('admin_bar_menu', [&$this , 'remove_wp_logo'], 999 );
        add_action('login_redirect', [&$this , 'login_redirect_by_role'], 10, 3);
        add_action('init', [&$this , 'wps_change_role_name']);
        add_action('user_register', [&$this , 'UserRegistrationListner'], 10, 3);

        add_filter('http_request_args', [&$this , 'CheckIfUpdated'], 5, 2 );
        add_filter('plugin_action_links_' . AA_BASENAME, [&$this, 'plugin_settings_link']);
        add_filter('pre_option_default_role', [&$this , 'SetDefaultRole']);
        add_filter('plugin_row_meta', [&$this ,'aa_plugin_meta_links'], 10, 2);
        add_filter('admin_footer_text', '__return_empty_string', 11 );
        add_filter('update_footer',     '__return_empty_string', 11 );

        // Enable shortcodes in text widgets
        add_filter('widget_text','do_shortcode');

    }

	/**
	 * @param $tag
	 * @param $function
	 */
	public static function ADD_ACTION($tag,$function){
		add_action( $tag, $function);
	}

	public static function ScriptFile(){
		foreach(self::fetchScript('assets/js') as $value){
			$name = explode("/",$value);
			wp_enqueue_script('aacommerce', plugins_url( $name[3].'/'.$name[4].'/'.$name[5],  dirname(__FILE__) ) );
		}
	}

	/**
	 *
	 */
	public static function StyleFile(){
		foreach(self::fetchStyle('assets/css') as $value){
			$name = explode("/",$value);
			wp_enqueue_style('aacommerce', plugins_url( $name[3].'/'.$name[4].'/'.$name[5],  dirname(__FILE__) ) );
		}
	}

	/**
	 *
	 */
	public static function loadcontrollers(){
		foreach (self::fetch(AA_PATH.'src/controllers') as $file) {
			self::need($file);
		}
	}

	/**
	 *
	 */
	public static function loadmodels(){
        $dirs = glob(AA_PATH.'add-ons/*', GLOB_MARK);
		foreach (self::fetch(AA_PATH.'src/models') as $file) {
			self::need($file);
		}
        foreach ($dirs as $dir) {
            foreach (self::fetch($dir.'/models') as $v) {
                self::need($v);
            }
        }
	}

    private static function LoadAddonClass(){
        $dirs = glob(AA_PATH .'add-ons/*', GLOB_MARK);
        $menu = null;
        foreach ($dirs as $dir) {
            if (is_dir($dir)) {
                $path        =  AA_PATH.'add-ons/'.basename($dir)."/";
                $menu        =  self::read($path."setting.json");
                $Mainclass   = $menu["class"];
                $boostrap    = $menu["boostrap"];
                $config      = $menu["Config"];
	            $Configclass = $menu["ConfigClass"];
	            require_once($path.$config);
                require_once($path.$boostrap);
                if(class_exists("$Mainclass")){
	                $Configclass::init();
	                $Mainclass::init();
                }else{
                    die("Cannot Load Addon Menu");
                    exit;
                }
            }
        }
    }

	/**
	 *
	 */
	public static function install() {
        //self::RemoveRoleByName();
        /*$result = add_role('client', 'Client',[
            'read'              => true, // true allows this capability
            'edit_posts'        => true, // Allows user to edit their own posts
            'edit_pages'        => true, // Allows user to edit pages
            'edit_others_posts' => true, // Allows user to edit others posts not just their own
            'create_posts'      => true, // Allows user to create new posts
            'manage_categories' => true, // Allows user to manage post categories
            'publish_posts'     => true, // Allows the user to publish, otherwise posts stays in draft mode
            'edit_themes'       => false, // false denies this capability. User can’t edit your theme
            'install_plugins'   => false, // User cant add new plugins
            'update_plugin'     => false, // User can’t update any plugins
            'update_core'       => false // user cant perform core updates
        ]);*/
	}

	/**
	 *
	 */
	public static function uninstall() {

	}

	/**
	 * FetchScript files of folder
	 */
	protected static function fetchScript($pattern)
	{
		return glob(AA_PATH. $pattern.'/*.js');
	}

	/**
	 * FetchStyle files of folder
	 */
	protected static function fetchStyle($pattern)
	{
		return glob(AA_PATH. $pattern.'/*.css');
	}

	/**
	 * @param $pattern
	 *
	 * @return array
	 */
	protected static function fetch($pattern)
	{
		return glob($pattern.'/*.php');
	}

	/**
	 * @param $path
	 *
	 * @return mixed
	 */
	protected static function need($path)
	{
		if(file_exists($path))
			return require $path;
	}

	protected static function setup()
	{
		// Register hooks that are fired when the plugin is activated and deactivated, respectively.
		register_activation_hook( __FILE__, ['AA_Core', 'install']);
		register_deactivation_hook( __FILE__, ['AA_Core', 'uninstall']);
	}

    public function remove_menus(){

        //remove_menu_page( 'index.php' );                  //Dashboard
        //remove_menu_page( 'jetpack' );                    //Jetpack*
        //remove_menu_page( 'edit.php' );                   //Posts
        //remove_menu_page( 'upload.php' );                 //Media
        //remove_menu_page( 'edit.php?post_type=page' );    //Pages
        //remove_menu_page( 'edit-comments.php' );          //Comments
        //remove_menu_page( 'users.php' );
        //remove_menu_page( 'tools.php' );
    }

    public function remove_wp_logo($wp_admin_bar) {
        $wp_admin_bar->remove_node( 'wp-logo' );
    }

    public function login_redirect_by_role( $redirect_to, $request, $user ) {
        if ( ! defined( 'DOING_AJAX' ) ) {
            if ( isset( $user->roles ) && is_array( $user->roles ) ) {
                if (in_array('administrator', $user->roles)) {
                    return $redirect_to;
                }elseif(in_array('editor', $user->roles)){
                    return $redirect_to;
                }elseif(in_array('author', $user->roles)){
                    return $redirect_to;
                }elseif(in_array('contributor', $user->roles)){
                    return $redirect_to;
                }elseif(in_array('teacher', $user->roles)){
                    return $redirect_to;
                }elseif(in_array('subscriber', $user->roles)){
                    return $redirect_to;
                }else {
                    return home_url();
                }
            } else {
                return $redirect_to;
            }
        }
    }

    public function wps_change_role_name() {
        global $wp_roles;
        if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();
        //Editor to Teacher
        $wp_roles->roles['editor']['name']   = 'Teacher';
        $wp_roles->role_names['editor']      = 'Teacher';

        //subscriber to Student
        $wp_roles->roles['subscriber']['name']   = 'Student';
        $wp_roles->role_names['subscriber']      = 'Student';
    }

    public function SetDefaultRole(){
        return 'subscriber';
    }

    public function UserRegistrationListner( $user_id ){
        require_once( ABSPATH . "wp-includes/pluggable.php" );
        $user_info  = get_userdata($user_id);
        $data       = (array) $user_info->data;

        // Do everything do you want
    }

    public function plugin_settings_link($links) {
        $url            = get_admin_url() . 'admin.php?page=aa.setting';
        $activated_url  = get_admin_url() . 'admin.php?page=aa.activation';
        $settings_link[] = '<a href="'.$url.'">' . __( 'Settings', 'textdomain' ) . '</a>';
        $settings_link[] = '<a href="'.$activated_url.'">' . __( 'Actived', 'textdomain' ) . '</a>';
        array_unshift( $links, $settings_link[1] );
        array_unshift( $links, $settings_link[0] );
        return $links;
    }

    public function aa_plugin_meta_links( $links, $file ) {
        if ( $file === 'aacommerce/aacommerce.php' ) {
            $links[] = '<a title="' . __( 'Pro Version' ) . '"><strong style="color:green">' . __( '[Pro Version]' ) . '</strong></a>';
        }
        return $links;
    }

    public function CheckIfUpdated( $r, $url ) {
        if ( 0 !== strpos( $url, 'http://api.wordpress.org/plugins/update-check' ) )
            return $r; // Not a plugin update request. Bail immediately.
        $plugins = unserialize( $r['body']['plugins'] );
        unset( $plugins->plugins[AA_BASENAME] );
        unset( $plugins->active[ array_search( AA_BASENAME, $plugins->active)]);
        $r['body']['plugins'] = serialize( $plugins );
        return $r;
    }

    public static function GetCurrentUserInfo(){
        require_once( ABSPATH . "wp-includes/pluggable.php" );
        $current_user = wp_get_current_user();
        return $current_user;
    }

    public static function GetAvatar(){
        return get_avatar_url(self::GetCurrentUserEmail(), 320);
    }

    private static function GetCurrentUserEmail(){
        require_once( ABSPATH . "wp-includes/pluggable.php" );
        $current_user = wp_get_current_user();
        return $current_user->user_email;
    }

    private function RemoveRoleByName(){
        if( get_role('pmpro_role_1') ){
            remove_role('pmpro_role_1');
        }
    }

    protected static function read($string)
    {
        $autoload = self::convert(file_get_contents($string));
        $autoload = $autoload["system"]["autoload"][0];
        return $autoload;
    }

    protected static function convert($string)
    {
        $data = json_decode($string,true);
        return $data;
    }
}
endif;