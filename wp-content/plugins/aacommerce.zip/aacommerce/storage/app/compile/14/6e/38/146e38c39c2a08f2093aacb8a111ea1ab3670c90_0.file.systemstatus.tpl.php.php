<?php
/* Smarty version 3.1.30, created on 2017-01-11 14:19:25
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/templates/admin/systemstatus.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58763eedae6bd4_05076203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '146e38c39c2a08f2093aacb8a111ea1ab3670c90' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/templates/admin/systemstatus.tpl.php',
      1 => 1483614759,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./layouts/app.tpl.php' => 1,
  ),
),false)) {
function content_58763eedae6bd4_05076203 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_136647648858763eedae5a25_11694469', 'content');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:./layouts/app.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'content'} */
class Block_136647648858763eedae5a25_11694469 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>
</section>
<?php
}
}
/* {/block 'content'} */
}
