<?php
/* Smarty version 3.1.30, created on 2017-01-14 11:30:24
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/shortcode/booking.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587a0bd0ac1784_88470362',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a3de5e153810c5bb1be28bc17b00a3366851a806' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/shortcode/booking.tpl.php',
      1 => 1484393414,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587a0bd0ac1784_88470362 (Smarty_Internal_Template $_smarty_tpl) {
if (!current_user_can("subscriber")) {?>
<div id="ss_calendar" class="DatepickerPosition"></div>
<div id="ss_events" class="timeList"></div>
<input type="hidden" name="ss_user_id" value="<?php echo get_current_user_id();?>
">
<?php }
}
}
