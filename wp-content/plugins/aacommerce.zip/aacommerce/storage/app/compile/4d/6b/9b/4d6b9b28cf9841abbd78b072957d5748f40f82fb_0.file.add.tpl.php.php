<?php
/* Smarty version 3.1.30, created on 2017-01-09 10:56:17
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/products/views/products/add.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58736c51c4eb35_84352731',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d6b9b28cf9841abbd78b072957d5748f40f82fb' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/products/views/products/add.tpl.php',
      1 => 1483960068,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58736c51c4eb35_84352731 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_149104149958736c51c4dff6_80192494', 'content');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender(@constant('AA_LAYOUTS_PATH'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, true);
}
/* {block 'content'} */
class Block_149104149958736c51c4dff6_80192494 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <h4><strong>Add New Product</strong></h4>
    </header>
    <section class="wrapper">
    <form action="#" method="post" id="form-prod">
        <div class="row">
        <div class="col-sm-9">
            <div class="col-sm-12" style="margin-bottom: 3%;padding-left: 0px;padding-right: 0px;">
                <input type="text" name="product_name" placeholder="Product name" class="form-control" style="height: 47px;font-size: 18px;">
            </div>
            <div class="col-sm-12" style="padding: 0;">
                <section class="panel clearfix" style="background: transparent;border: 0;">
                    <div class="panel-body" style="padding: 0px">
                        <?php echo wp_editor('','aa_product_form',array('textarea_name'=>'aa_description','media_buttons'=>false));?>

                    </div>
                </section>
            </div>
            <div class="col-sm-12" style="padding: 0px;">
                <section class="panel clearfix">
                    <header class="panel-heading font-bold">Product data</header>
                    <div>
                        <div class="wizard wizard-vertical clearfix" id="wizard-2">
                            <ul class="steps" style="width: 183px;">
                                <li data-target="#step4" class="active">General</li>
                                <li data-target="#step5">Attributes</li>
                                <li data-target="#step6">Advanced</li>
                            </ul>
                        </div>
                        <div class="step-content">
                            <div class="step-pane active" id="step4">
                                <p></p>
                            </div>
                            <div class="step-pane" id="step5">
                                <p></p>
                                <div class="progress progress-xs m-t-sm">
                                    <div class="progress-bar progress-bar-info" data-toggle="tooltip" data-original-title="40%" style="width: 40%"></div>
                                </div>
                                <p class="text-muted"></p>
                            </div>
                            <div class="step-pane" id="step6">
                                <p></p>
                            </div>
                            <div class="actions m-t text-right">
                                <button type="button" class="btn btn-white btn-sm btn-prev" data-target="#wizard-2" data-wizard="previous" disabled="disabled">Prev</button>
                                <button type="button" class="btn btn-white btn-sm btn-next" data-target="#wizard-2" data-wizard="next" data-last="Finish">Next</button>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading font-bold">Publish</header>
                    <div class="panel-body">
                        <button type="submit" class="button-primary">Publish</button>
                    </div>
                </section>
            </div>

            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading font-bold">Product categories</header>
                    <div class="panel-body">

                    </div>
                </section>
            </div>
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading font-bold">Product image</header>
                    <div class="panel-body">
                        <div id="product_picture"></div>
                        <p>
                            <button class="set_custom_images button" id="add-image-product" data-type="simple">Set product image</button>
                            <button class="button-primary" id="delete-image-product">Remove product image</button>
                        </p>
                    </div>
                </section>
            </div>
            <div class="col-sm-12">
                <section class="panel">
                    <header class="panel-heading font-bold">Product gallery</header>
                    <div class="panel-body">
                        <div id="gallery_picture"></div>
                        <p><button class="set_custom_images button" data-type="multiple">Add product gallery images</button></p>
                    </div>
                </section>
            </div>
        </div>
    </div>
        <input type="hidden" name="action" value="aa_add_product_action">
    </form>
    </section>

</section>
<?php
}
}
/* {/block 'content'} */
}
