<?php
/* Smarty version 3.1.30, created on 2017-01-13 09:21:56
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/add.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58789c34d37ee1_13823923',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '822775bdaf7315f17091ef6f26755e3ba7278310' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/add.tpl.php',
      1 => 1484299313,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58789c34d37ee1_13823923 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_68130984258789c34d2eb09_47845677', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_74446773658789c34d31391_12262858', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_167389830658789c34d36fe9_54260738', 'script');
?>


<?php $_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender(@constant('AA_LAYOUTS_PATH'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, true);
}
/* {block 'style'} */
class Block_68130984258789c34d2eb09_47845677 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css" type="text/css" />
<style>
    #footer-left{
        display: none;
    }
    .fc-toolbar.fc-header-toolbar {
        margin-left: 17px;
        margin-right: 17px;
    }
    .paddings{
        padding-left: 0px;
        padding-right: 0px;
    }
    .fc th, .fc-basic-view td {
        text-align: center;
    }
    .fc-ltr .fc-basic-view .fc-day-top .fc-day-number {
        font-weight: bold;
    }
    .fc table {
        font-size: 15px;
    }
    .fc-view-container{
        background: white;
    }
    .fc-today {
        background: #fcc44d !important;
        font-weight: bold;
        color: #fff;
    }
    .aside-md {
        width: 148px;
    }
</style>
<?php
}
}
/* {/block 'style'} */
/* {block 'content'} */
class Block_74446773658789c34d31391_12262858 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <h4><strong>Add New calendar</strong></h4>
    </header>
    <form action="#" method="post" id="form-prod">
        <section class="wrapper">
            <div class="row">
                <div class="col-sm-9">
                    <div class="col-sm-12" style="margin-bottom: 3%;padding-left: 0px;padding-right: 0px;">
                        <input type="text" name="product_name" placeholder="Calendar name" class="form-control" style="height: 47px;font-size: 18px;">
                    </div>
                    <div class="col-sm-12" style="padding: 0;">
                        <section class="panel clearfix" style="background: transparent;border: 0;">
                            <div class="panel-body" style="padding: 0px">
                                <div id='calendar'></div>
                            </div>
                        </section>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="col-sm-12">
                        <section class="panel">
                            <header class="panel-heading font-bold">Publish</header>
                            <div class="panel-body">
                                <button type="submit" class="button-primary">Publish</button>
                            </div>
                        </section>
                    </div>

                    <div class="col-sm-12">
                        <section class="panel">
                            <header class="panel-heading font-bold">Product categories</header>
                            <div class="panel-body">

                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
    </form>
</section>
<?php
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_167389830658789c34d36fe9_54260738 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    jQuery(document).ready(function() {
        var $        = jQuery,now = moment();
        var calendar = $('#calendar').fullCalendar({
            defaultDate: now,
            navLinks: false, // can click day/week names to navigate views
            editable: false,
            eventOverlap: false,
            selectOverlap: false,
            firstDay: 0,
            selectable: true,
            //weekends: false,
            hiddenDays: [7], // hidden sunday
            select: function(start, end) {
                var firstDate = start.format(), secondDate     = end.format(),oneDay = 24*60*60*1000;
                console.log("Selected", "");
            },
            header: {
                left: 'prev,today,next',
                center: 'title',
                right: 'month,listWeek'
            },
            viewRender: function(view,element) {
                var now = new Date();
                var end = new Date();
                end.setMonth(now.getMonth() + 3); //Adjust as needed

                if ( end < view.end) {
                    $("#calendar .fc-next-button").hide();
                    return false;
                }
                else {
                    $("#calendar .fc-next-button").show();
                }

                if ( view.start < now) {
                    $("#calendar .fc-prev-button").hide();
                    return false;
                }
                else {
                    $("#calendar .fc-prev-button").show();
                }
            },
            events: {
                type: "POST",
                url: ajaxurl,
                data: {
                    action: 'EventsCallback'
                },
                error: function() {
                    console.log('Error');
                }
            },
            dayClick: function(date,ob) {
                console.log('dayClick', date.format());
            }
        });

        //console.log(calendar)
    });
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
