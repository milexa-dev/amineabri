<?php
/* Smarty version 3.1.30, created on 2017-01-05 17:41:59
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/systemstatus.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586e8567578509_46914934',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '822a0205e34d36679e1a4dc675e89100a3d69298' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/systemstatus.tpl.php',
      1 => 1483614759,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./layouts/app.tpl.php' => 1,
  ),
),false)) {
function content_586e8567578509_46914934 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1420316566586e8567577b30_30979698', 'content');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:./layouts/app.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'content'} */
class Block_1420316566586e8567577b30_30979698 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>
</section>
<?php
}
}
/* {/block 'content'} */
}
