<?php
/* Smarty version 3.1.30, created on 2017-01-18 11:32:20
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/products/views/products/woocommerce-tab.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587f5244483183_57639232',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c60b41910d09e79af3b4380e5ad355ae2c6ea142' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/products/views/products/woocommerce-tab.tpl.php',
      1 => 1484739423,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587f5244483183_57639232 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- id below must match target registered in above add_my_custom_product_data_tab function -->
<div id="ss_availability" class="panel woocommerce_options_panel">
    <?php echo woocommerce_wp_select($_smarty_tpl->tpl_vars['calendar_field']->value);?>

</div><?php }
}
