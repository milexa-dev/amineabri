<?php
/* Smarty version 3.1.30, created on 2017-01-09 13:16:23
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/layouts/app.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58738d273ed2c3_39829533',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fd1e1fd668f1c503bdf9158199e9c99b33ef7adc' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/layouts/app.tpl.php',
      1 => 1483838204,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../inc/aside.tpl.php' => 1,
  ),
),false)) {
function content_58738d273ed2c3_39829533 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_120091476058738d273c9a62_39989304', 'style');
?>

</head>
<body>
<section class="hbox stretch">
    <?php $_smarty_tpl->_subTemplateRender("file:../inc/aside.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <!-- .vbox -->
    <section id="content">
        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_163059404858738d273e09f4_94989721', 'content');
?>

    </section>
    <!-- /.vbox -->
</section>
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_28868712458738d273ec2f0_58518733', 'script');
?>

</body>
</html><?php }
/* {block 'style'} */
class Block_120091476058738d273c9a62_39989304 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/bootstrap.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/animate.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/font.css" type="text/css" cache="false" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/js/fuelux/fuelux.css" type="text/css" />

    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/js/datatables/datatables.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/plugin.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/app.css" type="text/css" />
    <!--[if lt IE 9]>
    <?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/ie/respond.min.js" cache="false"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/ie/html5.js" cache="false"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/ie/fix.js" cache="false"><?php echo '</script'; ?>
>
    <![endif]-->
    <style>
        #wpbody-content {
            padding-bottom: 0px;
        }
    </style>
    <?php
}
}
/* {/block 'style'} */
/* {block 'content'} */
class Block_163059404858738d273e09f4_94989721 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_28868712458738d273ec2f0_58518733 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<!-- Bootstrap -->
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/bootstrap.js"><?php echo '</script'; ?>
>
<!-- Sparkline Chart -->
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/charts/sparkline/jquery.sparkline.min.js"><?php echo '</script'; ?>
>
<!-- App -->
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/app.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/app.plugin.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/app.data.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/fuelux/fuelux.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
