<?php
/* Smarty version 3.1.30, created on 2017-01-05 18:06:14
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/dashboard/widget/orders.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586e8b16901ac7_11313614',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '243ccc564a64bc31303fe20159c578560af3fcbe' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/dashboard/widget/orders.tpl.php',
      1 => 1480500345,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_586e8b16901ac7_11313614 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h1>List of Orders</h1><?php }
}
