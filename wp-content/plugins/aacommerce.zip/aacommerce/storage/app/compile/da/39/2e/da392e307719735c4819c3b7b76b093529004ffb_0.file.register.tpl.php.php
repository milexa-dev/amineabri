<?php
/* Smarty version 3.1.30, created on 2017-01-05 18:05:34
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/users/views/shortcode/register.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586e8aee2153f5_58204489',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'da392e307719735c4819c3b7b76b093529004ffb' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/users/views/shortcode/register.tpl.php',
      1 => 1483636669,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_586e8aee2153f5_58204489 (Smarty_Internal_Template $_smarty_tpl) {
?>
<form action="<?php echo $_SERVER['REQUEST_URI'];?>
" method="post">
    <div>
        <label for="username">Username <strong>*</strong></label>
        <input type="text" name="username" value="<?php if (isset($_smarty_tpl->tpl_vars['_POST']->value['username'])) {?> <?php echo $_smarty_tpl->tpl_vars['field']->value['username'];
}?>">
    </div>

    <div>
        <label for="password">Password <strong>*</strong></label>
        <input type="password" name="password" value="<?php if (isset($_smarty_tpl->tpl_vars['_POST']->value['password'])) {?> <?php echo $_smarty_tpl->tpl_vars['field']->value['password'];
}?>">
    </div>

    <div>
        <label for="email">Email <strong>*</strong></label>
        <input type="text" name="email" value="<?php if (isset($_smarty_tpl->tpl_vars['_POST']->value['email'])) {?> <?php echo $_smarty_tpl->tpl_vars['field']->value['email'];
}?>">
    </div>

    <div>
        <label for="firstname">First Name</label>
        <input type="text" name="fname" value="<?php if (isset($_smarty_tpl->tpl_vars['_POST']->value['fname'])) {?> <?php echo $_smarty_tpl->tpl_vars['field']->value['first_name'];
}?>">
    </div>

    <div>
        <label for="website">Last Name</label>
        <input type="text" name="lname" value="<?php if (isset($_smarty_tpl->tpl_vars['_POST']->value['lname'])) {?> <?php echo $_smarty_tpl->tpl_vars['field']->value['last_name'];
}?>">
    </div>

    <div>
        <label for="nickname">Nickname</label>
        <input type="text" name="nickname" value="<?php if (isset($_smarty_tpl->tpl_vars['_POST']->value['nickname'])) {?> <?php echo $_smarty_tpl->tpl_vars['field']->value['nickname'];
}?>">
    </div>

    <input type="submit" name="submit" value="Register"/>
</form><?php }
}
