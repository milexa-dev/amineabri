<?php
/* Smarty version 3.1.30, created on 2017-01-09 10:36:44
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/users/views/users/index.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587367bc17cea7_28888900',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd892d02fe9fe46438df852c10e556cc627f36b14' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/users/views/users/index.tpl.php',
      1 => 1483958894,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587367bc17cea7_28888900 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_740413006587367bc176c06_86169017', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1653140478587367bc17bff1_32907917', 'script');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender(@constant('AA_LAYOUTS_PATH'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, true);
}
/* {block 'content'} */
class Block_740413006587367bc176c06_86169017 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <p>Users</p>
    </header>
    <section class="panel" style="margin-bottom: 0px;">
        <div class="row text-sm wrapper">
            <div class="col-sm-5 m-b-xs">
                <select class="input-sm form-control input-s-sm inline">
                    <option value="0">Action</option>
                    <option value="1">Delete selected</option>
                    <option value="2">Edit</option>
                </select>
                <button class="btn btn-sm btn-white">Apply</button>
            </div>
            <div class="col-sm-4 m-b-xs">
            </div>
            <div class="col-sm-3">
                <div class="input-group">
                    <input type="text" class="input-sm form-control" placeholder="Search">
                    <span class="input-group-btn">
                        <button class="btn btn-sm btn-white" type="button">Go!</button>
                      </span>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t text-sm">
                <thead>
                <tr>
                    <th>Avatar</th>
                    <th>Username</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th width="30">Status</th>
                </tr>
                </thead>
                <tbody>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
?>
                <tr>
                    <td><?php echo get_avatar($_smarty_tpl->tpl_vars['user']->value['user_email'],'42');?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['user']->value['user_nicename'];?>
</td>
                    <td><?php echo get_user_meta($_smarty_tpl->tpl_vars['user']->value['ID'],'first_name',true);?>
</td>
                    <td><?php echo get_user_meta($_smarty_tpl->tpl_vars['user']->value['ID'],'last_name',true);?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['user']->value['user_email'];?>
</td>
                    <td><?php if ($_smarty_tpl->tpl_vars['user']->value['role'] == "subscriber") {?> Student <?php } elseif ($_smarty_tpl->tpl_vars['user']->value['role'] == "editor") {?> Teacher <?php } else { ?> <?php echo $_smarty_tpl->tpl_vars['user']->value['role'];?>
 <?php }?></td>
                    <td>
                        <a href="#" <?php if ($_smarty_tpl->tpl_vars['user']->value['user_status'] == 0) {?> class="active" <?php }?> data-toggle="class"><i class="icon-ok text-success text-active"></i><i class="icon-remove text-danger text"></i></a>
                    </td>
                </tr>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                </tbody>
            </table>
        </div>
        <footer class="panel-footer">
            <div class="row">
                <div class="col-sm-4 hidden-xs">
                    <select class="input-sm form-control input-s-sm inline">
                        <option value="0">Action</option>
                        <option value="1">Delete selected</option>
                        <option value="2">Edit</option>
                    </select>
                    <button class="btn btn-sm btn-white">Apply</button>
                </div>
                <div class="col-sm-4 text-center">
                    <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
                </div>
                <div class="col-sm-4 text-right text-center-xs">
                    <ul class="pagination pagination-sm m-t-none m-b-none">
                        <li><a href="#"><i class="icon-chevron-left"></i></a></li>
                        <li><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#"><i class="icon-chevron-right"></i></a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </section>
</section>
<?php
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_1653140478587367bc17bff1_32907917 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/datatables/jquery.dataTables.min.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
