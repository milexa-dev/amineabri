<?php
/* Smarty version 3.1.30, created on 2017-01-17 13:20:19
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/inc/aside.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587e1a13a9c9c3_71259529',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c5587b8093fec03b8434277f44293d9e94b05c17' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/inc/aside.tpl.php',
      1 => 1484298366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587e1a13a9c9c3_71259529 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- .aside -->
<aside class="bg-dark aside-sm nav-vertical" id="nav">
    <section class="vbox">
        <header class="dker nav-bar">
            <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="body">
                <i class="icon-reorder"></i>
            </a>
            <a class="btn btn-link visible-xs" data-toggle="class:show" data-target=".nav-user">
                <i class="icon-comment-alt"></i>
            </a>
        </header>
        <section>
            <!-- user -->
            <div class="bg-success nav-user hidden-xs pos-rlt">
                <div class="nav-avatar pos-rlt">
                    <a href="#" class="thumb-sm avatar animated rollIn" data-toggle="fullscreen">
                        <img src="<?php echo AA_Core::GetAvatar();?>
" alt="" class="">
                        <span class="caret caret-white"></span>
                    </a>
                    <div class="visible-xs m-t m-b">
                        <a href="#" class="h3">John.Smith</a>
                        <p><i class="icon-map-marker"></i> London, UK</p>
                    </div>
                </div>
                <div class="nav-msg">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <!--<b class="badge badge-white count-n">2</b>-->
                    </a>
                    <section class="dropdown-menu m-l-sm pull-left animated fadeInRight">
                        <div class="arrow left"></div>
                        <section class="panel bg-white">
                            <header class="panel-heading">
                                <strong>You have <span class="count-n">2</span> notifications</strong>
                            </header>
                            <div class="list-group">
                                <a href="#" class="media list-group-item">
                      <span class="pull-left thumb-sm">
                        <img src="<?php echo @constant('AA_URL');?>
assets/images/avatar.jpg" alt="John said" class="img-circle">
                      </span>
                                    <span class="media-body block m-b-none">
                        Use awesome animate.css<br>
                        <small class="text-muted">28 Aug 13</small>
                      </span>
                                </a>
                                <a href="#" class="media list-group-item">
                      <span class="media-body block m-b-none">
                        1.0 initial released<br>
                        <small class="text-muted">27 Aug 13</small>
                      </span>
                                </a>
                            </div>
                            <footer class="panel-footer text-sm">
                                <a href="#" class="pull-right"><i class="icon-cog"></i></a>
                                <a href="#">See all the notifications</a>
                            </footer>
                        </section>
                    </section>
                </div>
            </div>
            <!-- / user -->
            <!-- nav -->
            <nav class="nav-primary hidden-xs" style="">
                <!--<ul class="nav">
                    <li class="active">
                        <a href="index.html">
                            <i class="icon-dashboard"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <b class="badge bg-primary pull-right">3</b>
                            <i class="icon-envelope-alt"></i>
                            <span>Mail</span>
                        </a>
                    </li>
                    <li class="dropdown-submenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-archive"></i>
                            <span>Products</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="dashboard.html">Dashboard</a>
                            </li>
                            <li>
                                <a href="dashboard-1.html">Dashboard one</a>
                            </li>
                            <li>
                                <a href="gallery.html">Gallery</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">
                            <b class="badge bg-primary pull-right">3</b>
                            <i class="icon-user"></i>
                            <span>Users</span>
                        </a>
                    </li>
                </ul>-->
            </nav>
            <!-- / nav -->
        </section>
        <footer class="footer bg-gradient hidden-xs" style="display: none !important;">
            <a href="modal.lockme.html" data-toggle="ajaxModal" class="btn btn-sm btn-link m-r-n-xs pull-right">
                <i class="icon-off"></i>
            </a>
            <a href="#nav" data-toggle="class:nav-vertical" class="btn btn-sm btn-link m-l-n-sm">
                <i class="icon-reorder"></i>
            </a>
        </footer>

        <!-- note -->
        <div class="bg-danger wrapper hidden-vertical animated fadeInUp text-sm">
            <a href="#" data-dismiss="alert" class="pull-right m-r-n-sm m-t-n-sm"><i class="icon-close icon-remove "></i></a>
            Hi, welcome to todo,  you can start here.
        </div>
        <!-- / note -->
    </section>
</aside>
<!-- /.aside --><?php }
}
