<?php
/* Smarty version 3.1.30, created on 2017-01-17 09:10:43
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/products/views/products/tabs.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587ddf938b33c9_01820646',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '02a0217208b497680cbf88cbcb14684f6cc050a4' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/products/views/products/tabs.tpl.php',
      1 => 1484150117,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587ddf938b33c9_01820646 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="verticalTab">
    <ul class="resp-tabs-list">
        <li><span class="dashicons dashicons-admin-tools" style="font-size: 13px;vertical-align: -webkit-baseline-middle;"></span> General</li>
        <li><span class="dashicons dashicons-admin-settings" style="font-size: 13px;vertical-align: -webkit-baseline-middle;"></span> Attributes</li>
        <li><span class="dashicons dashicons-admin-generic" style="font-size: 13px;vertical-align: -webkit-baseline-middle;"></span> Advanced</li>
    </ul>
    <div class="resp-tabs-container">
        <div>
            <div class="options_group general show_if_simple show_if_external hidden" style="display: block;">
                <p class="form-field _regular_email_field">
                    <label for="email">Email</label>
                    <input type="text" class="short wc_input_email" name="_ss_email" value="<?php echo $_smarty_tpl->tpl_vars['email']->value;?>
" id="email">
                </p>
                <p class="form-field _regular_location_field ">
                    <label for="location">Location</label>
                    <input type="text" class="short wc_input_location" name="_ss_location" value="<?php echo $_smarty_tpl->tpl_vars['location']->value;?>
" id="location">
                </p>
                <p class="form-field _regular_type_field ">
                    <label for="_ss_type">Type</label><br/>
                    <select id="_ss_type" name="_ss_type">
                        <option value="Lessons" <?php if ($_smarty_tpl->tpl_vars['type']->value == 'Lessons') {?>selected="selected"<?php }?>>Lessons</option>
                        <option value="Online Lessons" <?php if ($_smarty_tpl->tpl_vars['type']->value == 'Online Lessons') {?>selected="selected"<?php }?>>Online Lessons</option>
                    </select>
                </p>
            </div>
        </div>
        <div>
            <div class="options_group pricing show_if_simple show_if_external hidden" style="display: block;">
                <p class="form-field _regular_price_field">
                    <label for="onehour">1 hour price (£)</label>
                    <input type="text" class="short wc_input_price" name="_ss_price[]" value="<?php echo $_smarty_tpl->tpl_vars['price_one']->value;?>
" id="onehour">
                </p>
                <p class="form-field _regular_price_field ">
                    <label for="90minutes">90 minutes price (£)</label>
                    <input type="text" class="short wc_input_price" name="_ss_price[]" value="<?php echo $_smarty_tpl->tpl_vars['price_two']->value;?>
" id="90minutes">
                </p>
                <p class="form-field _regular_price_field ">
                    <label for="30minutes">30 minutes price (£)</label>
                    <input type="text" class="short wc_input_price" name="_ss_price[]" value="<?php echo $_smarty_tpl->tpl_vars['price_three']->value;?>
" id="30minutes">
                </p>
            </div>
        </div>
        <div>
            <p>Suspendisse blandit velit Integer laoreet placerat suscipit. Sed sodales scelerisque commodo. Nam porta cursus lectus. Proin nunc erat, gravida a facilisis quis, ornare id lectus. Proin consectetur nibh quis Integer laoreet placerat suscipit. Sed sodales scelerisque commodo. Nam porta cursus lectus. Proin nunc erat, gravida a facilisis quis, ornare id lectus. Proin consectetur nibh quis urna gravid urna gravid eget erat suscipit in malesuada odio venenatis.</p>
        </div>
    </div>
</div><?php }
}
