<?php
/* Smarty version 3.1.30, created on 2017-01-05 18:06:14
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/dashboard/widget/welcome.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586e8b168b5b15_50288271',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2e1d64a5680924bb565de9199c050ad569bbe057' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/dashboard/widget/welcome.tpl.php',
      1 => 1480501717,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_586e8b168b5b15_50288271 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 type="text/javascript">
    // Hide default welcome message
    jQuery(document).ready( function($) {
        $('div.welcome-panel-content').hide();
    });
<?php echo '</script'; ?>
>
<div class="custum-welcome-panel-content">
    <h2>AACommerce Statistics</h2>
    <p class="about-description">Different Statistics:</p>
    <div class="welcome-panel-column-container">
        <div class="welcome-panel-column">
            <h3>Get Started</h3>
            <a class="button button-primary button-hero load-customize hide-if-no-customize" href="http://wordpress.dev/wp-admin/customize.php">Customise Your Site</a>
            <a class="button button-primary button-hero hide-if-customize" href="http://wordpress.dev/wp-admin/themes.php">Customise Your Site</a>
            <p class="hide-if-no-customize">or, <a href="http://wordpress.dev/wp-admin/themes.php">change your theme completely</a></p>
        </div>
        <div class="welcome-panel-column">
            <h3>Next Steps</h3>
            <ul>
                <li><a href="http://wordpress.dev/wp-admin/post-new.php" class="welcome-icon welcome-write-blog">Write your first blog post</a></li>
                <li><a href="http://wordpress.dev/wp-admin/post-new.php?post_type=page" class="welcome-icon welcome-add-page">Add an About page</a></li>
                <li><a href="http://wordpress.dev/" class="welcome-icon welcome-view-site">View your site</a></li>
            </ul>
        </div>
        <div class="welcome-panel-column welcome-panel-last">
            <h3>More Actions</h3>
            <ul>
                <li><div class="welcome-icon welcome-widgets-menus">Manage <a href="http://wordpress.dev/wp-admin/widgets.php">widgets</a> or <a href="http://wordpress.dev/wp-admin/nav-menus.php">menus</a></div></li>
                <li><a href="http://wordpress.dev/wp-admin/options-discussion.php" class="welcome-icon welcome-comments">Turn comments on or off</a></li>
                <li><a href="https://codex.wordpress.org/First_Steps_With_WordPress" class="welcome-icon welcome-learn-more">Learn more about getting started</a></li>
            </ul>
        </div>
    </div>
</div><?php }
}
