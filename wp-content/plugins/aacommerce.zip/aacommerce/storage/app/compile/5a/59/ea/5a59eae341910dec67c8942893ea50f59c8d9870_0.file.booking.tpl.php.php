<?php
/* Smarty version 3.1.30, created on 2017-01-18 13:16:13
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/calendars/views/shortcode/booking.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587f6a9d254352_66260263',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a59eae341910dec67c8942893ea50f59c8d9870' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/calendars/views/shortcode/booking.tpl.php',
      1 => 1484746501,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587f6a9d254352_66260263 (Smarty_Internal_Template $_smarty_tpl) {
if (current_user_can("subscriber") || current_user_can("administrator")) {?>
<div id="ss_calendar" class="DatepickerPosition"></div>
<div style="margin-bottom: 2px;margin-top: 2px"></div>
<div id="availabality">
    <div class="ss_times">
        <ul>
            <li><a href="#">08:00 - 09:00</a></li>
            <li><a href="#">09:00 - 10:00</a></li>
            <li><a href="#">10:00 - 11:00</a></li>
            <li><a href="#">11:00 - 12:00</a></li>
            <li><a href="#">12:00 - 13:00</a></li>
            <li><a href="#">13:00 - 14:00</a></li>
            <li><a href="#">14:00 - 15:00</a></li>
            <li><a href="#">15:00 - 16:00</a></li>
            <li><a href="#">16:00 - 17:00</a></li>
        </ul>
    </div>
</div>
<input type="hidden" name="ss_user_id" value="<?php echo get_current_user_id();?>
">
<?php }
}
}
