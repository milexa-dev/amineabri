<?php
/* Smarty version 3.1.30, created on 2017-01-10 11:40:16
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/products/views/products/filter.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5874c820de3738_07498583',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '57e38187504b2d36f354a745518c8a143ba2c2ce' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/products/views/products/filter.tpl.php',
      1 => 1484048918,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5874c820de3738_07498583 (Smarty_Internal_Template $_smarty_tpl) {
?>
<select name="ADMIN_FILTER_FIELD_NAME">
    <option value=""><?php echo _e('Filter By Custom Fields','baapf');?>
</option>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['fields']->value, 'field');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['field']->value) {
?>
        <?php if ((substr($_smarty_tpl->tpl_vars['field']->value[0],0,1) != "_")) {?>
            <?php if ($_smarty_tpl->tpl_vars['field']->value[0] == $_smarty_tpl->tpl_vars['current']->value) {?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['field']->value[0];?>
" selected="selected"><?php echo $_smarty_tpl->tpl_vars['field']->value[0];?>
</option>
            <?php } else { ?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['field']->value[0];?>
"><?php echo $_smarty_tpl->tpl_vars['field']->value[0];?>
</option>
            <?php }?>
        <?php }?>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</select>
<?php echo _e('Value:','baapf');?>

<input type="TEXT" name="ADMIN_FILTER_FIELD_VALUE" value="<?php echo $_smarty_tpl->tpl_vars['current_v']->value;?>
" /><?php }
}
