<?php
/* Smarty version 3.1.30, created on 2017-01-17 13:20:19
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/invitations.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587e1a13a0bd72_62376719',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '138b96b5b8fdd7fef02e3e9927cf338c5bee9fcb' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/invitations.tpl.php',
      1 => 1484385210,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_587e1a13a0bd72_62376719 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1266620758587e1a13a06285_14311310', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_137261685587e1a13a08650_39669251', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1230833008587e1a13a0b3a5_38227687', 'script');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender(@constant('AA_LAYOUTS_PATH'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, true);
}
/* {block 'style'} */
class Block_1266620758587e1a13a06285_14311310 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<style>
    #footer-left{
        display: none;
    }
    .position{
        position: absolute;
    }
</style>
<?php
}
}
/* {/block 'style'} */
/* {block 'content'} */
class Block_137261685587e1a13a08650_39669251 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <footer class="footer bg-light dker bg-gradient position">
        <p>Timeline</p>
    </footer>
    <section class="bg-light lter">
        <section class="hbox stretch">
            <!-- .aside -->
            <aside>
                <section class="vbox">
                    <section class="wrapper" style="overflow: scroll;height: 690px;">
                        <div class="timeline">
                            <article class="timeline-item active">
                                <div class="timeline-caption">
                                    <div class="panel bg-success lter no-borders">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-male time-icon bg-success"></i></span>
                                            <span class="timeline-date">Student XX</span>
                                            <h5>2017-01-17 07:30 pm</h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                            <div class="m-t-sm timeline-action">
                                                <button class="btn btn-sm btn-danger"><i class="icon-remove"></i> Cancel</button>
                                                <button class="btn btn-sm btn-white"><i class="icon-ok"></i> Confirm</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article class="timeline-item">
                                <div class="timeline-caption">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-ok time-icon bg-success"></i></span>
                                            <span class="timeline-date">2017-01-05 08:30 pm</span>
                                            <h5>
                                                <span>Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article class="timeline-item alt">
                                <div class="timeline-caption">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-ok time-icon bg-success"></i></span>
                                            <span class="timeline-date">2017-01-02 9:30 am</span>
                                            <h5>
                                                <span>Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article class="timeline-item">
                                <div class="timeline-caption">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-ok time-icon bg-success"></i></span>
                                            <span class="timeline-date">2016-12-17 11:30 am</span>
                                            <h5>
                                                <span>Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article class="timeline-item alt">
                                <div class="timeline-caption">
                                    <div class="panel bg-danger">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-remove-sign time-icon bg-danger"></i></span>
                                            <span class="timeline-date" style="color: #717171">2016-11-12 09:30 am</span>
                                            <h5>
                                                <span style="color: rgba(255, 255, 255, 0.8);">Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article class="timeline-item">
                                <div class="timeline-caption">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-ok time-icon bg-success"></i></span>
                                            <span class="timeline-date">2016-06-12  09:00 am</span>
                                            <h5>
                                                <span>Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article class="timeline-item alt">
                                <div class="timeline-caption">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-ok time-icon bg-success"></i></span>
                                            <span class="timeline-date">2017-01-02 9:30 am</span>
                                            <h5>
                                                <span>Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>

                            <article class="timeline-item">
                                <div class="timeline-caption">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <span class="timeline-icon"><i class="icon-ok time-icon bg-success"></i></span>
                                            <span class="timeline-date">2016-12-17 11:30 am</span>
                                            <h5>
                                                <span>Meeting</span>
                                                Student XX
                                            </h5>
                                            <p>Iaculis lorem justo porttitor orci. Vivamus vestibulum tortor augue. Donec elementum mollis velit.</p>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <div class="timeline-footer"><a href="#"><i class="icon-plus time-icon inline-block bg-dark"></i></a></div>
                        </div>
                    </section>
                </section>
            </aside>
            <!-- /.aside -->

        </section>
    </section>
</section>
<?php
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_1230833008587e1a13a0b3a5_38227687 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<?php
}
}
/* {/block 'script'} */
}
