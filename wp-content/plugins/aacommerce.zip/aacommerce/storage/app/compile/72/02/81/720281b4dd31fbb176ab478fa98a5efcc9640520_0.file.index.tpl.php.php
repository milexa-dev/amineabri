<?php
/* Smarty version 3.1.30, created on 2017-01-10 11:13:04
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/templates/admin/index.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5874c1c06b9fe9_79385447',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '720281b4dd31fbb176ab478fa98a5efcc9640520' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/templates/admin/index.tpl.php',
      1 => 1483638338,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./layouts/app.tpl.php' => 1,
  ),
),false)) {
function content_5874c1c06b9fe9_79385447 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7988102575874c1c06b94d3_07450218', 'content');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:./layouts/app.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'content'} */
class Block_7988102575874c1c06b94d3_07450218 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>

</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="body"></a>
<?php
}
}
/* {/block 'content'} */
}
