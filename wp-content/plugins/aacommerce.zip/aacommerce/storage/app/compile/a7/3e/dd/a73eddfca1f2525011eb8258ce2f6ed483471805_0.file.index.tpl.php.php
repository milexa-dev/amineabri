<?php
/* Smarty version 3.1.30, created on 2017-01-05 17:43:43
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/index.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586e85cfdbcd81_94363781',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a73eddfca1f2525011eb8258ce2f6ed483471805' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/index.tpl.php',
      1 => 1483638338,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./layouts/app.tpl.php' => 1,
  ),
),false)) {
function content_586e85cfdbcd81_94363781 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1204566771586e85cfdbc2d8_11230522', 'content');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:./layouts/app.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'content'} */
class Block_1204566771586e85cfdbc2d8_11230522 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>

</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="body"></a>
<?php
}
}
/* {/block 'content'} */
}
