<?php
/* Smarty version 3.1.30, created on 2017-01-14 09:19:42
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/index.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5879ed2e4efc45_58814488',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '32fc36f2369f2510248215178ed3d9060c99492d' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/index.tpl.php',
      1 => 1484385580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../inc/aside.tpl.php' => 1,
  ),
),false)) {
function content_5879ed2e4efc45_58814488 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14015787735879ed2e4e3d52_04366883', 'aside');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6513568935879ed2e4e82f9_24771444', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_240051095879ed2e4ea717_25321481', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13126138495879ed2e4eecd7_40467029', 'script');
?>


<?php $_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender(@constant('AA_LAYOUTS_PATH'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, true);
}
/* {block 'aside'} */
class Block_14015787735879ed2e4e3d52_04366883 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php $_smarty_tpl->_subTemplateRender("file:../inc/aside.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php
}
}
/* {/block 'aside'} */
/* {block 'style'} */
class Block_6513568935879ed2e4e82f9_24771444 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css" type="text/css" />
<style>
    #footer-left{
        display: none;
    }
    .fc-toolbar.fc-header-toolbar {
        margin-left: 17px;
        margin-right: 17px;
    }
    .paddings{
        padding-left: 0px;
        padding-right: 0px;
    }
    .fc th, .fc-basic-view td {
        text-align: center;
    }
    .fc-ltr .fc-basic-view .fc-day-top .fc-day-number {
        font-weight: bold;
    }
    .fc table {
        font-size: 15px;
    }
    .fc-view-container{
        background: white;
    }

</style>
<?php
}
}
/* {/block 'style'} */
/* {block 'content'} */
class Block_240051095879ed2e4ea717_25321481 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="wrapper paddings">
    <div id='calendar'></div>
</section>
<?php
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_13126138495879ed2e4eecd7_40467029 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    jQuery(document).ready(function() {
        var $   = jQuery,now = moment();
        $('#calendar').fullCalendar({
            defaultDate: now,
            navLinks: true, // can click day/week names to navigate views
            editable: false,
            eventOverlap: false,
            header: {
                left: 'prev,today,next',
                center: 'title',
                right: 'month,listWeek'
            },
            events: {
                type: "POST",
                url: ajaxurl,
                data: {
                    action: 'EventsCallback'
                },
                error: function() {
                    console.log('Error');
                }
            }
        });
        /*$("td a").addClass('badge bg-success');
        $(".fc-left button").on('click', function(){
            $("td a").addClass('badge bg-success');
        });*/
    });
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
