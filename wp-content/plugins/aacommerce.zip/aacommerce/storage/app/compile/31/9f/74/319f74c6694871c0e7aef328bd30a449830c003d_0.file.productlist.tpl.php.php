<?php
/* Smarty version 3.1.30, created on 2017-01-10 12:45:04
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/products/views/shortcode/productlist.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5874d750161ba2_79501201',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '319f74c6694871c0e7aef328bd30a449830c003d' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/products/views/shortcode/productlist.tpl.php',
      1 => 1484052805,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5874d750161ba2_79501201 (Smarty_Internal_Template $_smarty_tpl) {
?>
<ul>
    <?php if ($_smarty_tpl->tpl_vars['data']->value->have_posts()) {?>
    <?php
 while ($_smarty_tpl->tpl_vars['data']->value->have_posts()) {?>
    <li><?php echo $_smarty_tpl->tpl_vars['data']->value->the_post();?>
</li>
    <li><?php echo the_post_thumbnail();?>
</li>
    <li><?php echo the_content();?>
</li>
    <li>£ <?php echo get_post_meta(the_ID(),'_ss_regular_price',true);?>
</li>
    <?php }?>

    
    
    <?php }?>
</ul>
<?php }
}
