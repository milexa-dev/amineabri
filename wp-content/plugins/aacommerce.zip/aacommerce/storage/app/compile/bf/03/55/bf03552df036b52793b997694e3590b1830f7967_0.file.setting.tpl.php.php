<?php
/* Smarty version 3.1.30, created on 2017-01-05 17:42:00
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/setting.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_586e85686428e7_37112414',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf03552df036b52793b997694e3590b1830f7967' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/setting.tpl.php',
      1 => 1483614730,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./layouts/app.tpl.php' => 1,
  ),
),false)) {
function content_586e85686428e7_37112414 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_193836705586e8568641de4_43198280', 'content');
$_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender("file:./layouts/app.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'content'} */
class Block_193836705586e8568641de4_43198280 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>
</section>
<?php
}
}
/* {/block 'content'} */
}
