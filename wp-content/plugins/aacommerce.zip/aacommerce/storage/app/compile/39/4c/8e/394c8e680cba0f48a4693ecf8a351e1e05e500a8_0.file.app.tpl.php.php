<?php
/* Smarty version 3.1.30, created on 2017-01-17 13:20:15
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/layouts/app.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587e1a0fdbec55_37086312',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '394c8e680cba0f48a4693ecf8a351e1e05e500a8' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/templates/admin/layouts/app.tpl.php',
      1 => 1484220062,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../inc/aside.tpl.php' => 1,
  ),
),false)) {
function content_587e1a0fdbec55_37086312 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_305940398587e1a0fdac394_30740547', 'style');
?>

</head>
<body>
<section class="hbox stretch">
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1202243044587e1a0fdb02b1_81513011', 'aside');
?>

    <!-- .vbox -->
    <section id="content">
        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2004025289587e1a0fdb2365_71006729', 'content');
?>

    </section>
    <!-- /.vbox -->
</section>
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_242774919587e1a0fdbdd59_42241477', 'script');
?>

</body>
</html><?php }
/* {block 'style'} */
class Block_305940398587e1a0fdac394_30740547 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/bootstrap.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/animate.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/font.css" type="text/css" cache="false" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/js/fuelux/fuelux.css" type="text/css" />

    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/js/datatables/datatables.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/plugin.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo @constant('AA_URL');?>
assets/css/app.css" type="text/css" />
    <!--[if lt IE 9]>
    <?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/ie/respond.min.js" cache="false"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/ie/html5.js" cache="false"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/ie/fix.js" cache="false"><?php echo '</script'; ?>
>
    <![endif]-->
    <style>
        #wpbody-content {
            padding-bottom: 0px;
        }
    </style>
    <?php
}
}
/* {/block 'style'} */
/* {block 'aside'} */
class Block_1202243044587e1a0fdb02b1_81513011 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

        <?php $_smarty_tpl->_subTemplateRender("file:../inc/aside.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php
}
}
/* {/block 'aside'} */
/* {block 'content'} */
class Block_2004025289587e1a0fdb2365_71006729 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_242774919587e1a0fdbdd59_42241477 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<!-- Bootstrap -->
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/bootstrap.js"><?php echo '</script'; ?>
>
<!-- Sparkline Chart -->
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/charts/sparkline/jquery.sparkline.min.js"><?php echo '</script'; ?>
>
<!-- App -->
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/app.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/app.plugin.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/app.data.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo @constant('AA_URL');?>
assets/js/fuelux/fuelux.js"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
