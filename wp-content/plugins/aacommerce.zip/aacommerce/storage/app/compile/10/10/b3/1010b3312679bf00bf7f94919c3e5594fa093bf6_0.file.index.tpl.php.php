<?php
/* Smarty version 3.1.30, created on 2017-01-17 13:20:15
  from "/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/index.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_587e1a0fd2e081_94389226',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1010b3312679bf00bf7f94919c3e5594fa093bf6' => 
    array (
      0 => '/home/vagrant/Code/wordpress/wp-content/plugins/aacommerce/add-ons/calendars/views/calendars/index.tpl.php',
      1 => 1484385580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../inc/aside.tpl.php' => 1,
  ),
),false)) {
function content_587e1a0fd2e081_94389226 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_609685072587e1a0fd21346_40112180', 'aside');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_209436856587e1a0fd26281_62738941', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1927373997587e1a0fd28331_18051561', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_978279065587e1a0fd2cc93_35648560', 'script');
?>


<?php $_smarty_tpl->inheritance->endChild();
$_smarty_tpl->_subTemplateRender(@constant('AA_LAYOUTS_PATH'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, true);
}
/* {block 'aside'} */
class Block_609685072587e1a0fd21346_40112180 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php $_smarty_tpl->_subTemplateRender("file:../inc/aside.tpl.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php
}
}
/* {/block 'aside'} */
/* {block 'style'} */
class Block_209436856587e1a0fd26281_62738941 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css" type="text/css" />
<style>
    #footer-left{
        display: none;
    }
    .fc-toolbar.fc-header-toolbar {
        margin-left: 17px;
        margin-right: 17px;
    }
    .paddings{
        padding-left: 0px;
        padding-right: 0px;
    }
    .fc th, .fc-basic-view td {
        text-align: center;
    }
    .fc-ltr .fc-basic-view .fc-day-top .fc-day-number {
        font-weight: bold;
    }
    .fc table {
        font-size: 15px;
    }
    .fc-view-container{
        background: white;
    }

</style>
<?php
}
}
/* {/block 'style'} */
/* {block 'content'} */
class Block_1927373997587e1a0fd28331_18051561 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<section class="wrapper paddings">
    <div id='calendar'></div>
</section>
<?php
}
}
/* {/block 'content'} */
/* {block 'script'} */
class Block_978279065587e1a0fd2cc93_35648560 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php 
$_smarty_tpl->inheritance->callParent($_smarty_tpl, $this);
?>

<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    jQuery(document).ready(function() {
        var $   = jQuery,now = moment();
        $('#calendar').fullCalendar({
            defaultDate: now,
            navLinks: true, // can click day/week names to navigate views
            editable: false,
            eventOverlap: false,
            header: {
                left: 'prev,today,next',
                center: 'title',
                right: 'month,listWeek'
            },
            events: {
                type: "POST",
                url: ajaxurl,
                data: {
                    action: 'EventsCallback'
                },
                error: function() {
                    console.log('Error');
                }
            }
        });
        /*$("td a").addClass('badge bg-success');
        $(".fc-left button").on('click', function(){
            $("td a").addClass('badge bg-success');
        });*/
    });
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
