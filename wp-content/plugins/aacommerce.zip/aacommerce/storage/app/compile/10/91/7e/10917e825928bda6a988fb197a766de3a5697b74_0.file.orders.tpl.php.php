<?php
/* Smarty version 3.1.30, created on 2017-01-10 11:12:41
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/templates/admin/dashboard/widget/orders.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5874c1a90689d6_69003395',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10917e825928bda6a988fb197a766de3a5697b74' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/templates/admin/dashboard/widget/orders.tpl.php',
      1 => 1480500345,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5874c1a90689d6_69003395 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h1>List of Orders</h1><?php }
}
