<?php
/* Smarty version 3.1.30, created on 2017-01-10 12:59:51
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/products/views/shortcode/single.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5874dac76f9703_99481783',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f46b868ab8f1efa715a4c2394b949f7705adf57b' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/products/views/shortcode/single.tpl.php',
      1 => 1484053678,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5874dac76f9703_99481783 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['data']->value['post_title'];
}
}
