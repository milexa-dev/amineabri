<?php
/* Smarty version 3.1.30, created on 2017-01-12 16:17:18
  from "/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/inc/aside.tpl.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5877ac0ecfc9a4_01940823',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '908d3ac463c44f1f24a04ce21b91b9e1da1289cc' => 
    array (
      0 => '/home/vagrant/Code/wptemplatestarter/wp-content/plugins/aacommerce/add-ons/calendars/views/inc/aside.tpl.php',
      1 => 1484237837,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5877ac0ecfc9a4_01940823 (Smarty_Internal_Template $_smarty_tpl) {
?>
<aside class="aside aside-md bg-dark">
    <section class="vbox">
        <header class="dk header">
            <button class="btn btn-icon btn-default btn-sm pull-right visible-xs m-r-xs" data-toggle="class:show" data-target="#mail-nav"><i class="icon-reorder"></i></button>
            <p class="h4">Calendars</p>
        </header>
        <section>
            <section>
                <section id="mail-nav" class="hidden-xs">
                    <ul class="nav nav-pills nav-stacked no-radius m-t-sm">
                        <li>
                            <a href="#">
                                <i class="icon-circle text-danger pull-right m-t-xs"></i>
                                <strong>Booked</strong>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="icon-circle text-warning pull-right m-t-xs"></i>
                                <strong>Current day</strong>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="icon-circle pull-right m-t-xs"></i>
                                <strong>Available</strong>
                            </a>
                        </li>
                    </ul>
                </section>
            </section>
        </section>
    </section>
</aside><?php }
}
