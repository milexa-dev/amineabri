<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    {block name=style}
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/css/bootstrap.css" type="text/css" />
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/css/animate.css" type="text/css" />
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/css/font.css" type="text/css" cache="false" />
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/js/fuelux/fuelux.css" type="text/css" />

    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/js/datatables/datatables.css" type="text/css" />
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/css/plugin.css" type="text/css" />
    <link rel="stylesheet" href="{$smarty.const.AA_URL}assets/css/app.css" type="text/css" />
    <!--[if lt IE 9]>
    <script src="{$smarty.const.AA_URL}assets/js/ie/respond.min.js" cache="false"></script>
    <script src="{$smarty.const.AA_URL}assets/js/ie/html5.js" cache="false"></script>
    <script src="{$smarty.const.AA_URL}assets/js/ie/fix.js" cache="false"></script>
    <![endif]-->
    <style>
        #wpbody-content {
            padding-bottom: 0px;
        }
    </style>
    {/block}
</head>
<body>
<section class="hbox stretch">
    {block name=aside}
        {include file="../inc/aside.tpl.php"}
    {/block}
    <!-- .vbox -->
    <section id="content">
        {block name=content}{/block}
    </section>
    <!-- /.vbox -->
</section>
{block name=script}
<!-- Bootstrap -->
<script src="{$smarty.const.AA_URL}assets/js/bootstrap.js"></script>
<!-- Sparkline Chart -->
<script src="{$smarty.const.AA_URL}assets/js/charts/sparkline/jquery.sparkline.min.js"></script>
<!-- App -->
<script src="{$smarty.const.AA_URL}assets/js/app.js"></script>
<script src="{$smarty.const.AA_URL}assets/js/app.plugin.js"></script>
<script src="{$smarty.const.AA_URL}assets/js/app.data.js"></script>
<script src="{$smarty.const.AA_URL}assets/js/fuelux/fuelux.js"></script>
{/block}
</body>
</html>