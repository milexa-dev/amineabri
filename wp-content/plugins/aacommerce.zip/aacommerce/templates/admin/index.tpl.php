{extends file='./layouts/app.tpl.php'}
{block name=content}
<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>

</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="body"></a>
{/block}