{extends file='./layouts/app.tpl.php'}
{block name=content}
<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>
    <section class="scrollable wrapper">
        <div class="row">
            <div class="col-lg-4">
                <section class="panel">
                    <div class="text-center wrapper">
                        <div class="sparkline inline" data-type="pie" data-height="150" data-slice-colors="['#acdb83','#f2f2f2','#fb6b5b']">25000,23200,15000</div>
                    </div>
                    <ul class="list-group no-radius">
                        <li class="list-group-item">
                            <span class="pull-right">25,000</span>
                            <span class="label bg-success">1</span>
                            .inc company
                        </li>
                        <li class="list-group-item">
                            <span class="pull-right">23,200</span>
                            <span class="label bg-danger">2</span>
                            Gamecorp
                        </li>
                        <li class="list-group-item">
                            <span class="pull-right">15,000</span>
                            <span class="label bg-light">3</span>
                            Neosoft company
                        </li>
                    </ul>
                </section>
            </div>
            <div class="col-lg-4">
                <section class="panel no-borders">
                    <header class="panel-heading bg-success lter">
                        <span class="pull-right">Friday</span>
                        <span class="h4">$540<br>
                    <small class="text-muted">+1.05(2.15%)</small>
                  </span>
                        <div class="text-center padder m-b-n-sm m-t-sm">
                            <div class="sparkline" data-type="line" data-resize="true" data-height="65" data-width="100%" data-line-width="2" data-line-color="#fff" data-spot-color="#fff" data-fill-color="" data-highlight-line-color="#fff" data-spot-radius="3" data-data="[220,210,200,325,250,320,345,250,250,250,400,380]"></div>
                            <div class="sparkline inline" data-type="bar" data-height="45" data-bar-width="6" data-bar-spacing="10" data-bar-color="#92cf5c">9,9,11,10,11,10,12,10,9,10,11,9,8</div>
                        </div>
                    </header>
                    <div class="panel-body">
                        <div>
                            <span class="text-muted">Sales in June:</span>
                            <span class="h3 block">$2500.00</span>
                        </div>
                        <div class="row m-t-sm">
                            <div class="col-xs-4">
                                <small class="text-muted block">From market</small>
                                <span>$1500.00</span>
                            </div>
                            <div class="col-xs-4">
                                <small class="text-muted block">Referal</small>
                                <span>$600.00</span>
                            </div>
                            <div class="col-xs-4">
                                <small class="text-muted block">Affiliate</small>
                                <span>$400.00</span>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="col-lg-4">
                <section class="panel bg-info lter no-borders">
                    <div class="panel-body">
                        <a class="pull-right" href="#"><i class="icon-map-marker"></i></a>
                        <span class="h4">McLean, VA</span>
                        <div class="text-center padder m-t">
                            <span class="h1"><i class="icon-cloud text-muted"></i> 68°</span>
                        </div>
                    </div>
                    <footer class="panel-footer lt">
                        <div class="row">
                            <div class="col-xs-4">
                                <small class="text-muted block">Humidity</small>
                                <span>56 %</span>
                            </div>
                            <div class="col-xs-4">
                                <small class="text-muted block">Precip.</small>
                                <span>0.00 in</span>
                            </div>
                            <div class="col-xs-4">
                                <small class="text-muted block">Winds</small>
                                <span>7 mp</span>
                            </div>
                        </div>
                    </footer>
                </section>
            </div>
        </div>
    </section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="body"></a>
{/block}