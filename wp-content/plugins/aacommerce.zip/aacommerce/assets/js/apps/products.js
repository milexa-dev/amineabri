jQuery(document).ready(function() {
    var $ = jQuery;
    $("#delete-image-product").hide();
    if ($('.set_custom_images').length > 0) {
        if ( typeof wp !== 'undefined' && wp.media && wp.media.editor) {
            var file_frame;
            $(document).on('click', '.set_custom_images', function(e) {
                e.preventDefault();
                if($(this).attr('data-type') === 'multiple'){
                    file_frame = null;
                    if ( file_frame ) {
                        file_frame.open();
                        return;
                    }
                    // Create the media frame.
                    file_frame = wp.media.frames.file_frame = wp.media({ multiple: true });
                    file_frame.on( 'select', function() {
                        selection = file_frame.state().get('selection');
                        selection.map( function( attachment ) {
                            attachment = attachment.toJSON();
                            $("#gallery_picture").append('<article class="media">'+
                                '<a class="pull-left thumb m-t-xs">'+
                                '<img src="'+attachment.url+'">'+
                                '</a>'+
                                '<div class="media-body">'+
                                '<a href="#" class="font-semibold">'+attachment.name+'</a>'+
                                '<a href="#" data-id="'+attachment.id+'" class="text-xs block m-t-xs"><i class="icon-trash"></i> Remove</a>'+
                                '</div></article>'+
                                '<div class="line line-dashed"></div>');
                        });
                    });
                    // Finally, open the modal
                    file_frame.open();
                }else{
                    file_frame = null;
                    if ( file_frame ) {
                        file_frame.open();
                        return;
                    }
                    // Create the media frame.
                    file_frame = wp.media.frames.file_frame = wp.media({ multiple: false });
                    file_frame.on( 'select', function() {
                        attachment = file_frame.state().get('selection').first().toJSON();
                        $("#delete-image-product").show();
                        $("#add-image-product").hide();
                        $("#product_picture").html('<img src="'+attachment.url+'" style="width:100%" /><div class="line line-dashed"></div>')
                    });
                    // Finally, open the modal
                    file_frame.open();
                }
                return false;
            });
        }
    }

    $("#form-prod").submit(function( event ) {
        event.preventDefault();
        var data = $(this).serialize();
        $.ajax({
            type: "POST",
            url: ajaxurl,
            data: data,
            success: function(response){
                console.log(response);
            },
            error: function(MLHttpRequest, textStatus, errorThrown){
                console.log("There was an error: " + errorThrown);
            },
            timeout: 60000
        });
    });

    $('.woocommerce-variation-add-to-cart').hide();
    $('form.variations_form').on('change', '.variations select', function(){
        var value = $(this).val();
        if(value !== ''){
            $('.woocommerce-variation-add-to-cart').show();
        }else{
            $('.woocommerce-variation-add-to-cart').hide();
        }
    });
});