jQuery(document).ready(function() {
    var $        = jQuery;
    $('#ss_calendar').ss_calendar({
        ss_events: {
            url: "/wp-admin/admin-ajax.php",
            data: {
                action: 'BookingCallback'
            },
            type: "POST"
        },
        showOtherMonths: true,
        dateFormat: 'yy-mm-dd',
        multiMonths: 1,
        firstDay: 1
    });
});