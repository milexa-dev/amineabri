(function ( $ ) {
    var __picker = $.fn.datepicker;
    $.fn.ss_calendar = function(options) {
        var $self = this;
        if (options && (typeof options.ss_events === 'object')) {
            __picker.apply(this, [options]);
            if(!options.ss_events){
                return false;
            }
            var ss_ajax = options.ss_events;
            $.ajax({
                type: ss_ajax.type,
                url:  ss_ajax.url,
                data: ss_ajax.data,
                success: function(response){
                    var i = 0;
                    $self.datepicker("option", "onSelect", function(date){
                        $("#ss_events").empty();
                        var events  = response,
                            data    = [];

                        $.each( events, function(key , value ) {
                            data[key] = value.start;
                        });

                        if ($.inArray(date,data) !== -1) {
                            $("#ss_events").html('<label>Date : </label> <input type="text" value="'+date+'" name="bookingdate" id="bookingdate" />');
                            $("#bookingdate").css({
                                width:  "77%",
                                height: "21px"
                            });
                            $("#ss_events").css('display', 'inline-block').show("slide", { direction: "right" }, 1200);
                            return false;
                        }
                    });
                    $self.datepicker("option", "beforeShowDay", function(date) {
                        var DateFormat = new Date(date),
                            dateFinal  = DateFormat.getFullYear() + '-' + (('0' + (DateFormat.getMonth() + 1)).slice(-2)) + '-' + ('0'+ DateFormat.getDate()).slice(-2),
                            events     = response,
                            title      = "",
                            _class     = "",
                            data       = [];
                        $.each( events, function(key , value ) {
                            data[key] = value.start;
                        });
                        if ($.inArray(dateFinal,data) != -1) {
                            var position = $.inArray(dateFinal,data);
                            return [true, 'available', 'Available'];
                        } else {
                            return [true, "Unavailable ui-datepicker-unselectable", "Unavailable"];
                        }
                    });
                    $self.datepicker("option", "numberOfMonths",options.multiMonths);
                },
                error: function(MLHttpRequest, textStatus, errorThrown){
                    alert(errorThrown);
                }
            });
        }
    };


})( jQuery );