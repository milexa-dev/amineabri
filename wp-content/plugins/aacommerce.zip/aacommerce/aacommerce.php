<?php
/**
 * Plugin Name:     S.S Learning Managment System
 * Plugin URI:      http://www.sixthstory.co.uk
 * Github URI:      https://github.com/ar-framework-labs
 * Description:     Learning Managment System Plugin.
 * Author:          Amine Abri
 * Author URI:      http://www.amineabri.co.uk
 * Version:         1.0.0
 * License:         GPLv3 (ar-labs/license.txt)
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package         ArLabs
 * @author          Amine Abri <info@amineabri.co.uk>
 * @license         GNU General Public License, version 3
 * @copyright       2016-2017 amineabri.co.uk
 */

if (! defined('ABSPATH')) exit; // Exit if accessed directly.
define('AA_PATH', plugin_dir_path( __FILE__ ) );
define('AA_LAYOUTS_PATH', AA_PATH.'templates/admin/layouts/app.tpl.php');
define('AA_URL', plugin_dir_url( __FILE__ ) );
define('AA_BASENAME', plugin_basename( __FILE__ ) );

include_once(AA_PATH . 'vendor/autoload.php');
include_once(AA_PATH . 'src/class_aa_core.php');
include_once(AA_PATH . 'src/class_aa_template.php');
include_once(AA_PATH . 'src/class_aa_views.php');
include_once(AA_PATH . 'src/class_aa_shortcode.php');
include_once(AA_PATH . 'src/class_aa_menu.php');
include_once(AA_PATH . 'src/class_aa_widgets.php');
include_once(AA_PATH . 'src/class_aa_dashboardwidgets.php');
include_once(AA_PATH . 'src/class_aa_frontendpages.php');

new AA_Core();
