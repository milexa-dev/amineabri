<?php

if ( ! class_exists( 'UsersFrontendView') ) :
class UsersFrontendView
{
    public static function aa_page_cart() {
        $theme_dir      = get_stylesheet_directory() . '/aacommerce/aa-login.php';
        if(!file_exists($theme_dir)){
            if(is_page('cart')){
                include(AA_PATH."add-ons/users/views/frontend/aa-login.php");
                die();
            }
        }
    }

    public static function aa_page_products() {
        $theme_dir      = get_stylesheet_directory() . '/aacommerce/aa-register.php';
        if(!file_exists($theme_dir)){
            if(is_page('products')){
                include(AA_PATH."add-ons/users/views/frontend/aa-register.php");
                die();
            }
        }
    }

}
endif;