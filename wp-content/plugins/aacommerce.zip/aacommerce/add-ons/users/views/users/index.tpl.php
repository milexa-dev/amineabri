{extends file=$smarty.const.AA_LAYOUTS_PATH}
{block name=content}
<section class="vbox">
    <header class="header bg-white b-b">
        <p>Users</p>
    </header>
    <section class="panel" style="margin-bottom: 0px;">
        <div class="row text-sm wrapper">
            <div class="col-sm-5 m-b-xs">
                <select class="input-sm form-control input-s-sm inline">
                    <option value="0">Action</option>
                    <option value="1">Delete selected</option>
                    <option value="2">Edit</option>
                </select>
                <button class="btn btn-sm btn-white">Apply</button>
            </div>
            <div class="col-sm-4 m-b-xs">
            </div>
            <div class="col-sm-3">
                <div class="input-group">
                    <input type="text" class="input-sm form-control" placeholder="Search">
                    <span class="input-group-btn">
                        <button class="btn btn-sm btn-white" type="button">Go!</button>
                      </span>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t text-sm">
                <thead>
                <tr>
                    <th>Avatar</th>
                    <th>Username</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th width="30">Status</th>
                </tr>
                </thead>
                <tbody>
                {foreach from=$data item=user}
                <tr>
                    <td>{get_avatar( $user['user_email'], '42' )}</td>
                    <td>{$user['user_nicename']}</td>
                    <td>{get_user_meta($user['ID'], 'first_name', true)}</td>
                    <td>{get_user_meta($user['ID'], 'last_name', true)}</td>
                    <td>{$user['user_email']}</td>
                    <td>{if $user['role'] == "subscriber"} Student {elseif $user['role'] == "editor"} Teacher {else} {$user['role']} {/if}</td>
                    <td>
                        <a href="#" {if $user['user_status'] == 0} class="active" {/if} data-toggle="class"><i class="icon-ok text-success text-active"></i><i class="icon-remove text-danger text"></i></a>
                    </td>
                </tr>
                {/foreach}
                </tbody>
            </table>
        </div>
        <footer class="panel-footer">
            <div class="row">
                <div class="col-sm-4 hidden-xs">
                    <select class="input-sm form-control input-s-sm inline">
                        <option value="0">Action</option>
                        <option value="1">Delete selected</option>
                        <option value="2">Edit</option>
                    </select>
                    <button class="btn btn-sm btn-white">Apply</button>
                </div>
                <div class="col-sm-4 text-center">
                    <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
                </div>
                <div class="col-sm-4 text-right text-center-xs">
                    <ul class="pagination pagination-sm m-t-none m-b-none">
                        <li><a href="#"><i class="icon-chevron-left"></i></a></li>
                        <li><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li><a href="#"><i class="icon-chevron-right"></i></a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </section>
</section>
{/block}
{block name=script}
{$smarty.block.parent}
<script src="{$smarty.const.AA_URL}assets/js/datatables/jquery.dataTables.min.js"></script>
{/block}