<?php
/**
 * Template Name: AA_Registration
 *
 */

get_header();

?>
<div id="main-content" class="main-content">
    <div id="primary" class="content-area">
        <div id="content" class="site-content" role="main">
            <?php echo do_shortcode('[user_register_form]'); ?>
        </div><!-- #content -->
    </div><!-- #primary -->
    <?php get_sidebar( 'content' ); ?>
</div><!-- #main-content -->
<?php
get_sidebar();
get_footer();
?>