<form action="{$smarty.server.REQUEST_URI}" method="post">
    <div>
        <label for="username">Username <strong>*</strong></label>
        <input type="text" name="username" value="{if isset($_POST['username']) } {$field['username']}{/if}">
    </div>

    <div>
        <label for="password">Password <strong>*</strong></label>
        <input type="password" name="password" value="{if isset($_POST['password']) } {$field['password']}{/if}">
    </div>

    <div>
        <label for="email">Email <strong>*</strong></label>
        <input type="text" name="email" value="{if isset($_POST['email']) } {$field['email']}{/if}">
    </div>

    <div>
        <label for="firstname">First Name</label>
        <input type="text" name="fname" value="{if isset($_POST['fname']) } {$field['first_name']}{/if}">
    </div>

    <div>
        <label for="website">Last Name</label>
        <input type="text" name="lname" value="{if isset($_POST['lname']) } {$field['last_name']}{/if}">
    </div>

    <div>
        <label for="nickname">Nickname</label>
        <input type="text" name="nickname" value="{if isset($_POST['nickname']) } {$field['nickname']}{/if}">
    </div>

    <input type="submit" name="submit" value="Register"/>
</form>