<?php
if ( ! class_exists( 'UsersMenu') ) :
class UsersMenu {

	public static function load_menu(){
        //$logo = plugins_url( "products/",  dirname(__FILE__) )."logo.svg";
        /*add_menu_page(
            'ss-users',
            'SS-Users',
            'administrator',
            "ss-user",
            'AA_Users::index',
            'dashicons-admin-users',
            66
        );
        add_submenu_page(
            'ss-user',
            'All Users',
            'All Users',
            'administrator',
            'ss-user.list',
            'AA_Users::index'
        );

        add_submenu_page(
            'ss-user',
            'Add new',
            'Add new',
            'administrator',
            'ss-user.add',
            'AA_Users::add'
        );

        add_submenu_page(
            'ss-user',
            'Settings',
            'Settings',
            'administrator',
            'ss-user.settings',
            'AA_Users::settings'
        );

        add_submenu_page(
            'users.php',
            'Availability',
            'Availability',
            'administrator',
            'ss-user.availability',
            'AA_Users::availability'
        ); */
	}

    /**
     * Adds the order processing count to the menu.
     */
    public static function removeFirstMenu() {
        global $submenu;

        if ( isset( $submenu['ss-user'] ) ) {
            unset( $submenu['ss-user'][0] );
        }
    }
}
endif;
