<?php
/**
 * Class AA_Users.
 * User: Amine Abri
 * Date: 25/06/2016
 * Time: 14:19
 */
if ( ! class_exists( 'AA_Users') ) :
class AA_Users{

    public static function init()
    {
        $class = __CLASS__;
        new $class;
    }

    public function __construct(){
        //do_action('wp_loaded', [&$this, 'AddPages']);
    }

    public static function index(){
		$view   = new AA_Views();
		$users  = new AA_UserModel();
        $tpl = [
			"view"      => "users.index",
			"addon"     => "users"
		];
        $usersList = $users->getUserList();
		$view->makeAddonView($tpl,["data" => $usersList]);
	}

    public static function add(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "users.add",
            "addon"     => "users"
        ];
        $view->makeAddonView($tpl);
    }

    public static function settings(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "users.settings",
            "addon"     => "users"
        ];
        $view->makeAddonView($tpl);
    }

    public static function availability(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "users.settings",
            "addon"     => "users"
        ];
        $view->makeAddonView($tpl);
    }
}
endif;