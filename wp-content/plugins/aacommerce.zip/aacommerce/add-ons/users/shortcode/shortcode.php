<?php
if ( ! class_exists( 'UsersShortCode') ) :
class UsersShortCode {

    public static function shortcode_user_register_form() {
        $view = new AA_Views();
        $data = self::custom_registration_function();
        $tpl = [
            "view"      => "shortcode.register",
            "addon"     => "users"
        ];

        $view->makeAddonView($tpl,['field' => $data]);
    }


    private function registration_validation($username, $password, $email, $first_name, $last_name, $nickname )
    {
        global $reg_errors;
        $reg_errors = new WP_Error;
        if (empty($username) || empty($password) || empty($email)) {
            $reg_errors->add('field', 'Required form field is missing');
        }

        if (4 > strlen($username)) {
            $reg_errors->add('username_length', 'Username too short. At least 4 characters is required');
        }

        if (username_exists($username)){
            $reg_errors->add('user_name', 'Sorry, that username already exists!');
        }

        if ( ! validate_username( $username ) ) {
            $reg_errors->add( 'username_invalid', 'Sorry, the username you entered is not valid' );
        }

        if ( 5 > strlen( $password ) ) {
            $reg_errors->add( 'password', 'Password length must be greater than 5' );
        }

        if ( !is_email( $email ) ) {
            $reg_errors->add( 'email_invalid', 'Email is not valid' );
        }

        if ( email_exists( $email ) ) {
            $reg_errors->add( 'email', 'Email Already in use' );
        }


        if ( is_wp_error( $reg_errors ) ) {
            foreach ( $reg_errors->get_error_messages() as $error ) {
                echo '<div>';
                echo '<strong>ERROR</strong>:';
                echo $error . '<br/>';
                echo '</div>';
            }

        }
    }

    private function complete_registration() {
        global $reg_errors, $username, $password, $email, $first_name, $last_name, $nickname;
        if ( 1 > count( $reg_errors->get_error_messages() ) ) {
            $userdata = array(
                'user_login'    =>   $username,
                'user_email'    =>   $email,
                'user_pass'     =>   $password,
                'first_name'    =>   $first_name,
                'last_name'     =>   $last_name,
                'nickname'      =>   $nickname
            );
            $user = wp_insert_user( $userdata );
            echo 'Registration complete. Goto <a href="' . get_site_url() . '/wp-login.php">login page</a>.';
        }
    }

    private function custom_registration_function() {
        if ( isset($_POST['submit'] ) ) {
            self::registration_validation(
                $_POST['username'],
                $_POST['password'],
                $_POST['email'],
                $_POST['fname'],
                $_POST['lname'],
                $_POST['nickname']
            );

            // sanitize user form input
            global $username, $password, $email, $first_name, $last_name, $nickname;
            $username   =   sanitize_user( $_POST['username'] );
            $password   =   esc_attr( $_POST['password'] );
            $email      =   sanitize_email( $_POST['email'] );
            $first_name =   sanitize_text_field( $_POST['fname'] );
            $last_name  =   sanitize_text_field( $_POST['lname'] );
            $nickname   =   sanitize_text_field( $_POST['nickname'] );

            // call @function complete_registration to create the user
            // only when no WP_error is found
            self::complete_registration(
                $username,
                $password,
                $email,
                $first_name,
                $last_name,
                $nickname
            );

            $dataFields = [
                    'username'      =>$username,
                    'password'      =>$password,
                    'email'         =>$email,
                    'first_name'    =>$first_name,
                    'last_name'     =>$last_name,
                    'nickname'      =>$nickname
                ];
            return $dataFields;
        }
    }

}
endif;