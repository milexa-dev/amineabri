<?php
if ( ! class_exists( 'AA_UserModel') ) :
    class AA_UserModel {

        public static function getUserList($userlevel = 'all', $show_fullname = true){
            $wp_user_search = get_users('orderby=post_count&order=DESC');
            $data  = [];
            foreach($wp_user_search as $v){
                $data[]  = array_merge((array) $v->data,["role" => $v->roles[0]]);
            }
            return $data;
        }
    }
endif;