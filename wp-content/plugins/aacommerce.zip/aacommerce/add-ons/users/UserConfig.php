<?php
if ( ! class_exists( 'UserConfig') ) :
class UserConfig {
	public static function init()
	{
		$class = __CLASS__;
		new $class;
	}

	public function __construct(){
		//do_action('wp_loaded', [&$this, 'AddPages']);
	}



	public function AddPages(){
		wp_insert_post([
			"post_title"    => "Register",
			"post_content"  => "[user_register_form]",
			"post_status"   => "publish",
			"comment_status"=> "closed",
			"post_type"     => "page"
		]);
	}
}
endif;