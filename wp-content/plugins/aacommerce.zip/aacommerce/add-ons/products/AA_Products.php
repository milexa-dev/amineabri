<?php
/**
 * Class Captcha.
 * User: Amine Abri
 * Date: 25/06/2016
 * Time: 14:19
 */
if ( ! class_exists( 'AA_Products') ) :
class AA_Products{

    public static function init(){
        $class = __CLASS__;
        new $class;
    }

    public function __construct(){
        add_action('wp_ajax_aa_add_product_action', [&$this, 'addProductCallback']);
        add_action('wp_ajax_nopriv_aa_add_product_action', [&$this, 'addProductCallback']);
    }

    public static function index(){
        $args = array(
            'offset'           => 0,
            'category_name'    => '',
            'orderby'          => 'date',
            'order'            => 'DESC',
            'post_type'        => 'post',
            'post_status'      => 'publish'
        );
        $posts_array = get_posts( $args );
        echo "<pre>",print_r((array) $posts_array),"</pre>";
        exit;
		$view = new AA_Views();
        $tpl = [
			"view"      => "products.index",
			"addon"     => "products"
		];
		$view->makeAddonView($tpl);
	}

    public static function add(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "products.add",
            "addon"     => "products"
        ];
        $view->makeAddonView($tpl);
    }


    public static function addProductCallback(){

        wp_insert_post([
            "post_title"    => "Register",
            "post_content"  => "[user_register_form]",
            "post_status"   => "publish",
            "comment_status"=> "closed",
            "post_type"     => "ss_product"
        ]);

        wp_send_json($_POST['product_name']);
    }

    public static function categories(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "products.categories",
            "addon"     => "products"
        ];
        $view->makeAddonView($tpl);
    }

    public static function attributes(){
        $view = new AA_Views();
        $tpl = [
            "view"      => "products.attributes",
            "addon"     => "products"
        ];
        $view->makeAddonView($tpl);
    }

}
endif;