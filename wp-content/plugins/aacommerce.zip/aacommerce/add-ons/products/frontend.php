<?php

if ( ! class_exists( 'ProductsFrontendView') ) :
class ProductsFrontendView
{
    public static function aa_page_cart() {
        $theme_dir      = get_stylesheet_directory() . '/aacommerce/aa-cart.php';
        if(!file_exists($theme_dir)){
            if(is_page('cart')){
                include(AA_PATH."add-ons/products/views/frontend/aa-cart.php");
                die();
            }
        }
    }

    public static function aa_page_products() {
        $theme_dir      = get_stylesheet_directory() . '/aacommerce/aa-products.php';
        if(!file_exists($theme_dir)){
            if(is_page('products')){
                include(AA_PATH."add-ons/products/views/frontend/aa-products.php");
                die();
            }
        }
    }

}
endif;