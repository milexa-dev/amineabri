<?php
/**
 * Template Name: Products
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header();

?>
    <div id="main-content" class="main-content">
        <div id="primary" class="content-area">
            <div id="content" class="site-content" role="main">
                <h1>Product Core</h1>
                <?php
                $id = 30;
                echo do_shortcode('[product_single id="'.$id.'"]');

                ?>
            </div><!-- #content -->
        </div><!-- #primary -->
    </div><!-- #main-content -->
<?php
get_footer();
?>