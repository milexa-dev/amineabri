{extends file=$smarty.const.AA_LAYOUTS_PATH}
{block name=content}
<section class="vbox">
    <header class="header bg-white b-b">
        <p>Welcome to todo application</p>
    </header>
</section>
{/block}