<div id="verticalTab">
    <ul class="resp-tabs-list">
        <li><span class="dashicons dashicons-admin-tools" style="font-size: 13px;vertical-align: -webkit-baseline-middle;"></span> General</li>
        <li><span class="dashicons dashicons-admin-settings" style="font-size: 13px;vertical-align: -webkit-baseline-middle;"></span> Attributes</li>
        <li><span class="dashicons dashicons-admin-generic" style="font-size: 13px;vertical-align: -webkit-baseline-middle;"></span> Advanced</li>
    </ul>
    <div class="resp-tabs-container">
        <div>
            <div class="options_group general show_if_simple show_if_external hidden" style="display: block;">
                <p class="form-field _regular_email_field">
                    <label for="email">Email</label>
                    <input type="text" class="short wc_input_email" name="_ss_email" value="{$email}" id="email">
                </p>
                <p class="form-field _regular_location_field ">
                    <label for="location">Location</label>
                    <input type="text" class="short wc_input_location" name="_ss_location" value="{$location}" id="location">
                </p>
                <p class="form-field _regular_type_field ">
                    <label for="_ss_type">Type</label><br/>
                    <select id="_ss_type" name="_ss_type">
                        <option value="Lessons" {if $type == 'Lessons'}selected="selected"{/if}>Lessons</option>
                        <option value="Online Lessons" {if $type == 'Online Lessons'}selected="selected"{/if}>Online Lessons</option>
                    </select>
                </p>
            </div>
        </div>
        <div>
            <div class="options_group pricing show_if_simple show_if_external hidden" style="display: block;">
                <p class="form-field _regular_price_field">
                    <label for="onehour">1 hour price (£)</label>
                    <input type="text" class="short wc_input_price" name="_ss_price[]" value="{$price_one}" id="onehour">
                </p>
                <p class="form-field _regular_price_field ">
                    <label for="90minutes">90 minutes price (£)</label>
                    <input type="text" class="short wc_input_price" name="_ss_price[]" value="{$price_two}" id="90minutes">
                </p>
                <p class="form-field _regular_price_field ">
                    <label for="30minutes">30 minutes price (£)</label>
                    <input type="text" class="short wc_input_price" name="_ss_price[]" value="{$price_three}" id="30minutes">
                </p>
            </div>
        </div>
        <div>
            <p>Suspendisse blandit velit Integer laoreet placerat suscipit. Sed sodales scelerisque commodo. Nam porta cursus lectus. Proin nunc erat, gravida a facilisis quis, ornare id lectus. Proin consectetur nibh quis Integer laoreet placerat suscipit. Sed sodales scelerisque commodo. Nam porta cursus lectus. Proin nunc erat, gravida a facilisis quis, ornare id lectus. Proin consectetur nibh quis urna gravid urna gravid eget erat suscipit in malesuada odio venenatis.</p>
        </div>
    </div>
</div>