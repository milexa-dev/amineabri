<!-- id below must match target registered in above add_my_custom_product_data_tab function -->
<div id="ss_availability" class="panel woocommerce_options_panel">
    {woocommerce_wp_select($calendar_field)}
</div>