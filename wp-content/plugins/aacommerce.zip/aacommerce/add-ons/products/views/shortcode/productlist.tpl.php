<ul>
    {if $data->have_posts()}
    {while $data->have_posts()}
    <li>{$data->the_post()}</li>
    <li>{the_post_thumbnail()}</li>
    <li>{the_content()}</li>
    <li>£ {get_post_meta(the_ID(), '_ss_regular_price',true)}</li>
    {/while}
    {*next_posts_link( 'Older Entries', $data->max_num_pages )*}
    {*previous_posts_link( 'Newer Entries' )*}
    {/if}
</ul>
