<?php
if ( ! class_exists( 'ProductsShortCode') ) :
class ProductsShortCode {

    public static function shortcode_product_list_by_category() {
        $view = new AA_Views();
        $tpl = [
            "view"      => "shortcode.productlist",
            "addon"     => "products"
        ];
        $loop = new WP_Query([
            'post_type'      => 'product',
            'posts_per_page' => -1
        ]);
        $view->makeAddonView($tpl,['data' => $loop]);

    }

    public static function shortcode_product_single($attr) {
        extract( shortcode_atts([
            'slug' => ''
        ], $attr ) );

        $view = new AA_Views();
        $tpl = [
            "view"      => "shortcode.single",
            "addon"     => "products"
        ];

        $args = [
            'name'        => $attr['slug'],
            'post_type'   => 'product',
            'post_status' => 'publish',
            'numberposts' => 1
        ];

        $post = get_posts($args)[0];
        //echo "<pre>",print_r( $post);
        $view->makeAddonView($tpl,['data' => (array) $post]);
    }

}
endif;