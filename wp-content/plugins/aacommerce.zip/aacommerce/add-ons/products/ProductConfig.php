<?php
if ( ! class_exists( 'ProductConfig') ) :
class ProductConfig {

	public static function init(){
		$class = __CLASS__;
		new $class;
	}

	public function __construct(){
		add_action ('admin_enqueue_scripts', [&$this, 'MediaButton']);
		add_action('init', [&$this, 'ss_post_product']);
		add_action('admin_head', [$this, 'menu_icon_css']);
		add_action('admin_init',[$this, 'ss_add_role_caps'],999);
		add_filter('woocommerce_product_data_tabs',    [$this, 'add_availability_data_tab'] , 99 , 1 );
		add_action('woocommerce_product_data_panels',  [$this, 'add_my_custom_product_data_fields']);
		add_action('woocommerce_process_product_meta', [$this, 'woocommerce_process_product_meta_fields_save']);
		add_action('admin_head',                       [$this, 'change_meta_box_title']);
		add_action('admin_menu',                       [$this,'rename_woocoomerce_wpse_100758'], 999 );

		//enqueu
		wp_enqueue_style('product-tab-style', AA_URL . 'assets/add-ons/products/css/product.css', [], '1.0.0' );
		wp_enqueue_script('ajax-script', AA_URL . 'assets/js/apps/products.js', ['jquery'], '1.0.0', true );

		//filters
		add_filter('enter_title_here',                       [$this, 'ss_change_field_name']);
		add_filter('woocommerce_product_tabs',               [$this, 'remove_review_tab'], 99);
		add_filter('woocommerce_taxonomy_args_product_cat',  [$this, 'custom_wc_taxonomy_args_product_cat']);
		add_filter('woocommerce_taxonomy_args_product_tag',  [$this, 'custom_wc_taxonomy_args_product_tag']);
		add_filter('woocommerce_product_data_tabs',          [$this, 'remove_linked_products'], 10, 1);
		add_filter('default_product_type',                   [$this, 'cartible_change_default_product_type']);
		add_filter('product_type_selector',                  [$this,'cartible_product_type_selector'], 10, 2 );
		add_theme_support('post-thumbnails',                 ['product']);

	}
	public function ss_post_product() {
		$labels = [
			'name'               => _x( 'Teachers', 'post type general name' ),
			'singular_name'      => _x( 'Teacher', 'post type singular name' ),
			'add_new'            => _x( 'Add Teacher', 'book' ),
			'add_new_item'       => __( 'Add New Teacher' ),
			'edit_item'          => __( 'Edit Teacher' ),
			'new_item'           => __( 'New Teacher' ),
			'all_items'          => __( 'Teachers' ),
			'view_item'          => __( 'View Teacher' ),
			'search_items'       => __( 'Search Teachers' ),
			'not_found'          => __( 'No Teachers found' ),
			'not_found_in_trash' => __( 'No Teachers found in the Trash' ),
			'featured_image'     => __( 'Teacher image', 'text_domain' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'Teachers',
		];
		$args = [
			'labels'            => $labels,
			'description'       => '',
			'public'            => true,
			'menu_position'     => 65,
			//'menu_icon'         => AA_URL.'assets/images/teacher.svg',
			'supports'          => ['title', 'editor', 'thumbnail'],
			'has_archive'       => true,
			'show_in_admin_bar' => true,
			'show_in_menu'      => true,
			'capability_type'   => ["product","products"],
			'map_meta_cap'      => true
		];

		register_post_type('product', $args );
	}

	public function ss_change_field_name( $title ){
		$screen = get_current_screen();
		if  ( 'product' == $screen->post_type ) {
			$title = 'Teacher name';
		}
		return $title;
	}

	public function menu_icon_css() {
		echo '<style>#adminmenu .wp-menu-image img{padding-top: 1px;}#featured_image{width: 8%;}</style>';
	}

	public function ss_add_role_caps(){
		// Add the roles you'd like to administer the custom post types
		$roles = ['administrator'];
		// Loop through each role and assign capabilities
		foreach ($roles as $the_role) {
			$role = get_role($the_role);
			$role->add_cap('read');
			$role->add_cap('read_product');
			$role->add_cap('read_private_products');
			$role->add_cap('edit_product');
			$role->add_cap('edit_products');
			$role->add_cap('edit_others_products');
			$role->add_cap('edit_published_products');
			$role->add_cap('publish_products');
			$role->add_cap('delete_others_products');
			$role->add_cap('delete_private_products');
			$role->add_cap('delete_published_products');
		}
	}


	//Custom tab Woocommerce
	public function add_availability_data_tab( $product_availability_data_tabs ) {
		$product_availability_data_tabs['ss-availability'] = [
			'label'  =>  __( 'Availability', 'woocommerce'),
			'target' => 'ss_availability',
		];
		return $product_availability_data_tabs;
	}

	public function add_my_custom_product_data_fields() {
		$view = new AA_Views();
		$tpl = [
			"view"      => "products.woocommerce-tab",
			"addon"     => "products"
		];

		global $post;
		$post_args = [
			'post_type'     => 'ss_calendar',
			'post_status'   => 'publish'
		];
		$data = get_posts($post_args);
		$res  = [];
		if(!empty($data)) {
			foreach ($data as $value ) {
				$res[] = [$value->ID => __($value->post_title, 'woocommerce' )];
			}
		}

		$view->makeAddonView($tpl,['calendar_field' => [
			'id'            => '_ss_calendar',
			'label'         => __( 'Select calendar :', 'woocommerce' ),
			'wrapper_class' => 'calendar_select',
			'options'       => $res,
			'default'       => 'one',
			'description'   => __( 'Select a calendar for this teacher', 'woocommerce'),
			'desc_tip'      => true
		]]);
	}

	public function woocommerce_process_product_meta_fields_save( $post_id ){
		// This is the case to save custom field data of checkbox. You have to do it as per your custom fields
		$woo_checkbox = isset( $_POST['_ss_calendar'] ) ? $_POST['_ss_calendar'] : '';
		update_post_meta( $post_id, '_ss_calendar', $woo_checkbox );

		// $woocommerce_ss_calendar
		$woocommerce_ss_calendar = $_POST['_ss_calendar'];
		if( !empty( $woocommerce_ss_calendar ) )
			update_post_meta( $post_id, '_ss_calendar', esc_attr( $woocommerce_ss_calendar ) );

	}
	//--- Finish
	public function change_meta_box_title() {
		remove_meta_box( 'postimagediv', 'product', 'side' );
		remove_meta_box( 'woocommerce-product-images', 'product', 'side' );
		add_meta_box('postimagediv', __('Teacher image'), 'post_thumbnail_meta_box', 'product', 'side', 'high');

	}

	public function remove_review_tab($tabs){
		unset($tabs['reviews']);
		return $tabs;
	}

	public function custom_wc_taxonomy_args_product_cat( $args ) {
		$args['label'] = __( 'Instruments', 'woocommerce' );
		$args['labels'] = array(
			'name' 				=> __( 'Teacher Instruments', 'woocommerce' ),
			'singular_name' 	=> __( 'Teacher Instrument', 'woocommerce' ),
			'menu_name'			=> _x( 'Instruments', 'Admin menu name', 'woocommerce' ),
			'search_items' 		=> __( 'Search Teacher Instruments', 'woocommerce' ),
			'all_items' 		=> __( 'All Teacher Instruments', 'woocommerce' ),
			'parent_item' 		=> __( 'Parent Teacher Instrument', 'woocommerce' ),
			'parent_item_colon' => __( 'Parent Teacher Instrument:', 'woocommerce' ),
			'edit_item' 		=> __( 'Edit Teacher Instrument', 'woocommerce' ),
			'update_item' 		=> __( 'Update Teacher Instrument', 'woocommerce' ),
			'add_new_item' 		=> __( 'Add New Teacher Instrument', 'woocommerce' ),
			'new_item_name' 	=> __( 'New Teacher Instrument Name', 'woocommerce' )
		);

		return $args;
	}

	public function custom_wc_taxonomy_args_product_tag( $args ) {
		$args['label'] = __( 'Teacher Tags', 'woocommerce' );
		$args['labels'] = array(
			'name' 				=> __( 'Teacher Tags', 'woocommerce' ),
			'singular_name' 	=> __( 'Teacher Tag', 'woocommerce' ),
			'menu_name'			=> _x( 'Tags', 'Admin menu name', 'woocommerce' ),
			'search_items' 		=> __( 'Search Teacher Tags', 'woocommerce' ),
			'all_items' 		=> __( 'All Teacher Tags', 'woocommerce' ),
			'parent_item' 		=> __( 'Parent Teacher Tag', 'woocommerce' ),
			'parent_item_colon' => __( 'Parent Teacher Tag:', 'woocommerce' ),
			'edit_item' 		=> __( 'Edit Teacher Tag', 'woocommerce' ),
			'update_item' 		=> __( 'Update Teacher Tag', 'woocommerce' ),
			'add_new_item' 		=> __( 'Add New Teacher Tag', 'woocommerce' ),
			'new_item_name' 	=> __( 'New Teacher Tag Name', 'woocommerce' )
		);

		return $args;
	}

	public function rename_woocoomerce_wpse_100758() {
		global $menu;

		// Pinpoint menu item
		$woo = self::recursive_array_search_php_91365( 'WooCommerce', $menu );

		// Validate
		if( !$woo )
			return;
		$menu[$woo][0] = 'Store Settings';
	}

	public function recursive_array_search_php_91365( $needle, $haystack ) {
		foreach( $haystack as $key => $value ) {
			$current_key = $key;
			if(
				$needle === $value
				OR (
					is_array( $value )
					&& self::recursive_array_search_php_91365( $needle, $value ) !== false
				)
			)
			{
				return $current_key;
			}
		}
		return false;
	}

	public function remove_linked_products($tabs){
		unset($tabs['inventory']);
		unset($tabs['shipping']);
		unset($tabs['linked_product']);
		return($tabs);
	}

	public static function MediaButton() {
		if (is_admin ()){
			wp_enqueue_media();
		}
	}

	public function cartible_change_default_product_type() {
		return 'variable';
	}

	/**
	 * Remove product types we do not want to be shown.
	 */
	public function cartible_product_type_selector( $product_types ) {
		unset( $product_types['grouped'] );
		unset( $product_types['external'] );
		return $product_types;
	}

}
endif;