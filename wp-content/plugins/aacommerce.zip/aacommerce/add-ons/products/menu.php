<?php
if ( ! class_exists( 'ProductsMenu') ) :
class ProductsMenu {

	public static function load_menu(){
        //$logo = plugins_url( "products/",  dirname(__FILE__) )."logo.svg";
        /*add_menu_page(
            'products',
            'SS-Products',
            'administrator',
            "product",
            'AA_Products::index',
            'dashicons-products',
            66
        );
        add_submenu_page(
            'product',
            'Products',
            'Products',
            'administrator',
            'product.list',
            'AA_Products::index'
        );

        add_submenu_page(
            'product',
            'Add Product',
            'Add Product',
            'administrator',
            'product.add',
            'AA_Products::add'
        );

        add_submenu_page(
            'product',
            'Categories',
            'Categories',
            'administrator',
            'product.categories',
            'AA_Products::categories'
        );

        add_submenu_page(
            'product',
            'Attributes',
            'Attributes',
            'administrator',
            'product.attributes',
            'AA_Products::attributes'
        );*/



        /*add_submenu_page(
            'edit.php?post_type=product',
            'Attributes',
            'Attributes',
            'administrator',
            'product.attributes',
            'AA_Products::attributes'
        );*/
	}

    /**
     * Adds the order processing count to the menu.
     */
    public static function removeFirstMenu() {
        global $submenu;

        if ( isset( $submenu['product'] ) ) {
            unset( $submenu['product'][0] );
        }
    }
}
endif;
