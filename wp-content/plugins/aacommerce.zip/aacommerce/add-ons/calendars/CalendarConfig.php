<?php
if ( ! class_exists( 'CalendarConfig') ) :
class CalendarConfig {

	public static function init()
	{
		$class = __CLASS__;
		new $class;
	}

	public function __construct(){
		add_action('wp_enqueue_scripts', [&$this, 'LoadAssets']);
		add_action('init', [&$this, 'ss_post_calendar']);
		//add_action('admin_init',[$this, 'ss_add_role_caps'],999);

		//filter
		add_filter('enter_title_here', [$this, 'ss_change_field_name']);
	}

	public static function LoadAssets(){
		/*wp_enqueue_style('ss_calendar_normalize', AA_URL."assets/add-ons/calendars/css/normalize.css");
		wp_enqueue_style('ss_calendar_datepicker', AA_URL."assets/add-ons/calendars/css/datepicker.css");
		wp_enqueue_script('ss_calendar_jquery-ui',AA_URL."assets/add-ons/calendars/js/jquery-ui-1.8.18.custom.min.js",['jquery'],'1.8.18');
		wp_enqueue_script('ss_calendar',AA_URL."assets/add-ons/calendars/js/calendar.js");
		wp_enqueue_script('ss_calendar_app',AA_URL."assets/add-ons/calendars/js/app.js");*/

		wp_enqueue_style('highlight-zenburn', "//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.7/styles/zenburn.min.css",[],8.7);
		wp_enqueue_style('highlight', "//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.7/highlight.min.js",[],8.7);
		wp_enqueue_style('datepickk', AA_URL."assets/add-ons/calendar-2/dist/datepickk.min.css");

		wp_enqueue_script('datepickk',AA_URL."assets/add-ons/calendar-2/dist/datepickk.js");
		wp_enqueue_script('datepickk-app',AA_URL."assets/add-ons/calendar-2/dist/app.js");
	}

	public function ss_post_calendar() {
		$labels = [
			'name'               => _x( 'Calendars', 'ss_calendar'),
			'singular_name'      => _x( 'Calendar', 'ss_calendar'),
			'add_new'            => _x( 'Add Calendar', 'book' ),
			'add_new_item'       => __( 'Add New Calendar' ),
			'edit_item'          => __( 'Edit Calendar' ),
			'new_item'           => __( 'New Calendar' ),
			'all_items'          => __( 'Calendars' ),
			'view_item'          => __( 'View Calendar' ),
			'search_items'       => __( 'Search Calendars' ),
			'not_found'          => __( 'No Calendars found' ),
			'not_found_in_trash' => __( 'No Calendars found in the Trash' ),
			'featured_image'     => __( 'Calendar image', 'text_domain' ),
			'parent_item_colon'  => '',
			'menu_name'          => 'S.Calendar',
		];
		$args = [
			'labels'            => $labels,
			'description'       => '',
			'public'            => true,
			'menu_position'     => 65,
			'menu_icon'         => 'dashicons-calendar-alt',
			'supports'          => ['title'],
			'has_archive'       => true,
			'show_in_admin_bar' => true,
			'show_in_menu'      => true,
			//'capability_type'   => ["product","products"],
			'map_meta_cap'      => true
		];

		register_post_type('ss_calendar', $args );
	}

	public function ss_change_field_name( $title ){
		$screen = get_current_screen();
		if  ( 'ss_calendar' == $screen->post_type ) {
			$title = 'Calendar name';
		}
		return $title;
	}

	public function ss_add_role_caps(){
		// Add the roles you'd like to administer the custom post types
		$roles = ['administrator','subscriber'];
		// Loop through each role and assign capabilities
		foreach ($roles as $the_role) {
			$role = get_role($the_role);
			$role->add_cap('read');
			$role->add_cap('read_calendar');
			$role->add_cap('read_private_products');
			$role->add_cap('edit_product');
			$role->add_cap('edit_products');
			$role->add_cap('edit_others_products');
			$role->add_cap('edit_published_products');
			$role->add_cap('publish_products');
			$role->add_cap('delete_others_products');
			$role->add_cap('delete_private_products');
			$role->add_cap('delete_published_products');
		}
	}
}
endif;