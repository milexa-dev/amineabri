<?php
if ( ! class_exists( 'CalendarsShortCode') ) :
class CalendarsShortCode {
    public static function shortcode_ss_booking_calendar($attr) {
        extract( shortcode_atts([
            'user_id' => ''
        ], $attr ) );

        $view = new AA_Views();
        $tpl = [
            "view"      => "shortcode.booking",
            "addon"     => "calendars"
        ];
        $view->makeAddonView($tpl);
    }
}
endif;