<?php
if ( ! class_exists( 'AA_CalendarModel') ) :
    class AA_CalendarModel {


    }
endif;