<?php
/**
 * Class AA_Calendars.
 * User: Amine Abri
 * Date: 25/06/2016
 * Time: 14:19
 */
if ( ! class_exists( 'AA_Calendars') ) :
class AA_Calendars{

    public static function init()
    {
        $class = __CLASS__;
        new $class;
    }

    public function __construct(){
	    add_action('wp_ajax_EventsCallback', [&$this,  'EventsCallback']);
	    add_action('wp_ajax_BookingCallback', [&$this, 'BookingCallback']);
	    //add_action('wp_enqueue_scripts', [&$this, 'LoadAssets']);
    }

	public static function EventsCallback(){
        // Read and parse our events JSON file into an array of event data arrays.
        $json         = file_get_contents(AA_PATH. 'events.json');
        $input_arrays = json_decode($json, true);
        wp_send_json($input_arrays);
    }

	public static function BookingCallback(){
        // Read and parse our events JSON file into an array of event data arrays.
        $json         = file_get_contents(AA_PATH. 'availabality.json');
        $input_arrays = json_decode($json, true);
        wp_send_json($input_arrays);
    }

	public static function LoadAssets(){
		wp_enqueue_style('ss_calendar_normalize', AA_URL."assets/add-ons/calendars/css/normalize.css");
		wp_enqueue_style('ss_calendar_datepicker', AA_URL."assets/add-ons/calendars/css/datepicker.css");
		wp_enqueue_script('ss_calendar_jquery-ui',AA_URL."assets/add-ons/calendars/js/jquery-ui-1.8.18.custom.min.js",['jquery'],'1.8.18');
		wp_enqueue_script('ss_calendar',AA_URL."assets/add-ons/calendars/js/calendar.js");
		wp_enqueue_script('ss_calendar_app',AA_URL."assets/add-ons/calendars/js/app.js");
	}

}
endif;