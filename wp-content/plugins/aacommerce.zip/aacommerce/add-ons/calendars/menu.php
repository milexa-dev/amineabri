<?php
if ( ! class_exists( 'CalendarsMenu') ) :
class CalendarsMenu {

	public static function load_menu(){
        //$logo = plugins_url( "products/",  dirname(__FILE__) )."logo.svg";
       /* add_menu_page(
            'ss-calendars',
            'S.Calendar',
            'administrator',
            "ss-calendar",
            'AA_Calendars::index',
            'dashicons-calendar-alt',
            67
        );
        add_submenu_page(
            'ss-calendar',
            'Calendar',
            'Calendar',
            'administrator',
            'ss-calendar.list',
            'AA_Calendars::index'
        );
        add_submenu_page(
            'ss-calendar',
            'Add calendar',
            'Add calendar',
            'administrator',
            'ss-calendar.add',
            'AA_Calendars::addForm'
        );
        add_submenu_page(
            'ss-calendar',
            'Invitations',
            'Invitations',
            'administrator',
            'ss-calendar.invitations',
            'AA_Calendars::invitations'
        );*/
	}

    /**
     * Adds the order processing count to the menu.
     */
    public static function removeFirstMenu() {
        global $submenu;

        if ( isset( $submenu['ss-calendar'] ) ) {
            unset( $submenu['ss-calendar'][0] );
        }
    }
}
endif;
