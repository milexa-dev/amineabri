<?php

if ( ! class_exists('CalendarsFrontendView') ) :
class CalendarsFrontendView
{
}
endif;