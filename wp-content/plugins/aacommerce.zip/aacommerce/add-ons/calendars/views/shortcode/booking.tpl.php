{if current_user_can("subscriber") || current_user_can("administrator")}
<div id="ss_calendar" class="DatepickerPosition"></div>
<div style="margin-bottom: 2px;margin-top: 2px"></div>
<div id="availabality">
    <div class="ss_times">
        <ul>
            <li><a href="#">08:00 - 09:00</a></li>
            <li><a href="#">09:00 - 10:00</a></li>
            <li><a href="#">10:00 - 11:00</a></li>
            <li><a href="#">11:00 - 12:00</a></li>
            <li><a href="#">12:00 - 13:00</a></li>
            <li><a href="#">13:00 - 14:00</a></li>
            <li><a href="#">14:00 - 15:00</a></li>
            <li><a href="#">15:00 - 16:00</a></li>
            <li><a href="#">16:00 - 17:00</a></li>
        </ul>
    </div>
</div>
<input type="hidden" name="ss_user_id" value="{get_current_user_id()}">
{/if}